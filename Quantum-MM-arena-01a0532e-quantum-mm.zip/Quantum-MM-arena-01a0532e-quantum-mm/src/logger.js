const levels = Object.freeze({ debug: 10, info: 20, warn: 30, error: 40 });
const minimum = levels[process.env.LOG_LEVEL?.toLowerCase()] ?? levels.info;

function write(level, message, details = {}) {
  if (levels[level] < minimum) return;
  const timestamp = new Date().toISOString();
  const suffix = Object.keys(details).length ? ` | ${JSON.stringify(details)}` : '';
  const line = `[${timestamp}] ${level.toUpperCase().padEnd(5)} quantum-mm ${message}${suffix}`;
  if (level === 'error') console.error(line);
  else if (level === 'warn') console.warn(line);
  else console.log(line);
}

export const logger = Object.freeze({
  debug: (message, details) => write('debug', message, details),
  info: (message, details) => write('info', message, details),
  warn: (message, details) => write('warn', message, details),
  error: (message, details) => write('error', message, details)
});

export function action(message, details = {}) {
  logger.info(message, details);
}

export function security(message, details = {}) {
  logger.warn(message, details);
}
