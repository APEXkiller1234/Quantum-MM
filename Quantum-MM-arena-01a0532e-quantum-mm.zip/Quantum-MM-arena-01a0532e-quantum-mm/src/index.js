import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Events } from 'discord.js';
import { config, validateConfig } from './config.js';
import { registerCommands } from './commands.js';
import { createClient } from './bot.js';
import { logger, action } from './logger.js';
import { DataStore } from './storage/dataStore.js';
import { BlockchainService } from './services/blockchainService.js';
import { TicketService } from './services/ticketService.js';
import { MonitorService } from './services/monitorService.js';
import { CountdownService } from './services/countdownService.js';
import { DemoService } from './services/demoService.js';
import { startHealthServer } from './services/healthServer.js';
import { registerInteractionHandler } from './handlers/interactionHandler.js';

const root = resolve(fileURLToPath(new URL('..', import.meta.url)));

async function main() {
  validateConfig();
  const client = createClient();
  const store = new DataStore(resolve(root, 'middleman_data.json'), config.ticket.startingNumber);
  await store.init();
  const blockchain = new BlockchainService();
  const tickets = new TicketService({ client, store, blockchain });
  const monitor = new MonitorService({ store, blockchain, tickets });
  const countdown = new CountdownService({ store, tickets });
  const demo = new DemoService({ client, blockchain });
  const healthServer = startHealthServer({ store, client, monitor });

  tickets.setMonitorHooks({ start: (ticket) => monitor.start(ticket), stop: (channelId) => monitor.stop(channelId) });
  tickets.setCountdownHooks({ start: (...args) => countdown.start(...args), cancel: (...args) => countdown.cancel(...args) });
  registerInteractionHandler(client, { config, store, tickets, monitor, countdown });

  client.once(Events.ClientReady, async (readyClient) => {
    action('bot_ready', { user: readyClient.user.tag, guilds: readyClient.guilds.cache.size });
    try {
      await registerCommands();
      await monitor.resume();
      await countdown.resume();
      await tickets.resumeCompletedOutputs();
      demo.start();
    } catch (error) {
      logger.error('Startup resume failed', { error: error.message });
    }
  });

  client.on(Events.Error, (error) => logger.error('Discord client error', { error: error.message }));
  client.on(Events.Warn, (message) => logger.warn('Discord warning', { message }));
  await client.login(config.discord.token);

  const shutdown = async (signal) => {
    action('shutdown_started', { signal });
    demo.stop();
    for (const ticket of Object.values(store.snapshot.tickets)) monitor.stop(ticket.channelId);
    healthServer.close();
    await client.destroy();
    process.exit(0);
  };
  process.once('SIGINT', () => shutdown('SIGINT'));
  process.once('SIGTERM', () => shutdown('SIGTERM'));
}

main().catch((error) => {
  logger.error('Fatal startup error', { error: error.message });
  process.exitCode = 1;
});
