import crypto from 'node:crypto';
import { EmbedBuilder, Events } from 'discord.js';
import { logger, action, security } from '../logger.js';
import { FUNDED_STATUSES } from '../services/ticketService.js';
import { addressConfirmationPayload, addressModal, addressPromptPayload, cancellationPayload, componentIds, colorsForUi, paymentInfoPayload, proceedPayload, releaseConfirmationPayload, roleConfirmationPayload, roleSelectionPayload, simpleNotice, usdConfirmationPayload } from '../ui/components.js';
import { assetLongName, assetName, cryptoAmount, isAdmin, isReceiver, isSender, money, parsePositiveDecimal, sleep, userIsParty } from '../utils/format.js';

function ephemeral(content) { return { content, ephemeral: true }; }

async function reply(interaction, payload) {
  if (interaction.deferred || interaction.replied) return interaction.followUp(payload);
  return interaction.reply(payload);
}

async function requireTicket(interaction, tickets) {
  const ticket = tickets.get(interaction.channelId);
  if (!ticket) {
    await reply(interaction, ephemeral('This ticket is no longer active.'));
    return null;
  }
  return ticket;
}

function partyOrAdmin(interaction, ticket) {
  return userIsParty(interaction, ticket) || isAdmin(interaction);
}

function statsEmbed(user, stats) {
  return new EmbedBuilder().setTitle(`${user.globalName ?? user.username} · Middleman Stats`).setDescription(`**Deals Completed**\n${Number(stats?.dealsCompleted ?? 0)}\n\n**Total USD Value**\n${money(stats?.totalUsdValue ?? 0)}`).setColor(colorsForUi().neutral).setThumbnail(user.displayAvatarURL());
}

function ticketInfoEmbed(ticket) {
  return new EmbedBuilder().setTitle(`Ticket ${ticket.number} · ${ticket.status}`).setColor(colorsForUi().neutral).addFields(
    { name: 'Asset', value: assetLongName(ticket), inline: true },
    { name: 'USD value', value: money(ticket.usdAmount ?? 0), inline: true },
    { name: 'Sender', value: ticket.senderId ? `<@${ticket.senderId}>` : 'Not selected', inline: true },
    { name: 'Receiver', value: ticket.receiverId ? `<@${ticket.receiverId}>` : 'Not selected', inline: true },
    { name: 'Deposit', value: ticket.depositAmount ? `${cryptoAmount(ticket, ticket.depositAmount)} ${assetName(ticket)}` : 'Not detected', inline: true },
    { name: 'Deposit transaction', value: `\`${ticket.depositTxid ?? 'N/A'}\``, inline: false },
    { name: 'Payout', value: ticket.payoutAmount ? `${cryptoAmount(ticket, ticket.payoutAmount)} ${assetName(ticket)}` : 'Not settled', inline: true },
    { name: 'Payout transaction', value: `\`${ticket.payoutTxid ?? 'N/A'}\``, inline: false }
  ).setTimestamp(new Date(ticket.createdAt));
}

async function handleCommand(interaction, context) {
  const { tickets, store, monitor } = context;
  switch (interaction.commandName) {
    case 'panel': {
      if (!isAdmin(interaction)) return reply(interaction, ephemeral('You do not have permission to use this command.'));
      const { panelPayload } = await import('../ui/components.js');
      action('panel_sent', { userId: interaction.user.id, guildId: interaction.guildId, channelId: interaction.channelId });
      return interaction.reply(panelPayload());
    }
    case 'stats': {
      const user = interaction.options.getUser('user');
      return interaction.reply({ embeds: [statsEmbed(user, store.snapshot.stats[String(user.id)])] });
    }
    case 'leaderboard': {
      const limit = interaction.options.getInteger('limit') ?? 5;
      const rows = Object.entries(store.snapshot.stats).sort(([, a], [, b]) => Number(b.dealsCompleted ?? 0) - Number(a.dealsCompleted ?? 0)).slice(0, limit);
      if (!rows.length) return interaction.reply('No completed trades have been recorded yet.');
      const description = rows.map(([id, stats], index) => `**${index + 1}.** <@${id}> — ${Number(stats.dealsCompleted ?? 0)} deals · ${money(stats.totalUsdValue ?? 0)}`).join('\n');
      return interaction.reply({ embeds: [new EmbedBuilder().setTitle('Quantum-MM Leaderboard').setDescription(description).setColor(colorsForUi().purple).setFooter({ text: 'Only completed settlements are counted' })] });
    }
    case 'setprivacy': {
      const privateValue = interaction.options.getBoolean('private', true);
      store.snapshot.privacy[String(interaction.user.id)] = privateValue;
      store.addAudit('privacy_changed', { userId: interaction.user.id, private: privateValue });
      await store.save();
      action('privacy_changed', { userId: interaction.user.id, private: privateValue });
      return interaction.reply(ephemeral(privateValue ? 'Your identity is now hidden in completed-trade posts.' : 'Your identity will now be displayed in completed-trade posts.'));
    }
    case 'ticket-info': {
      const ticket = tickets.getByNumber(interaction.options.getInteger('ticket_number', true));
      if (!ticket) return interaction.reply(ephemeral('Ticket not found.'));
      if (!partyOrAdmin(interaction, ticket)) return interaction.reply(ephemeral('Only the ticket traders or an administrator can view this ticket.'));
      return interaction.reply({ embeds: [ticketInfoEmbed(ticket)], ephemeral: true });
    }
    case 'mark-deposit': {
      if (String(interaction.user.id) !== String(context.config.discord.ownerUserId)) {
        security('unauthorized_mark_deposit_attempt', { userId: interaction.user.id });
        return interaction.reply(ephemeral('You cannot use this command.'));
      }
      await interaction.deferReply({ ephemeral: true });
      try {
        const ticket = await tickets.markDeposit(interaction.options.getInteger('ticket_number', true), interaction.options.getString('amount', true), interaction.options.getInteger('confirmation', true));
        return interaction.editReply(`Deposit state shown for ticket ${ticket.number}.`);
      } catch (error) {
        return interaction.editReply(error.message);
      }
    }
    case 'settle': {
      if (!isAdmin(interaction)) return interaction.reply(ephemeral('You do not have permission to use this command.'));
      const ticket = tickets.getByNumber(interaction.options.getInteger('ticket_number', true));
      if (!ticket) return interaction.reply(ephemeral('Ticket not found.'));
      if (ticket.status !== 'settlementPending') return interaction.reply(ephemeral('That ticket is not waiting for settlement.'));
      await interaction.deferReply({ ephemeral: true });
      const txid = interaction.options.getString('payout_txid', true).trim();
      try {
        const verification = await tickets.settleTicket(ticket, txid, interaction.options.getString('payout_amount', true));
        action('settlement_verified', { ticket: ticket.number, admin: interaction.user.id, txid, confirmations: verification.confirmations });
        return interaction.editReply(`Settlement verified and recorded. Confirmed payout amount: ${cryptoAmount(ticket, verification.actualAmount)} ${assetName(ticket)}.`);
      } catch (error) {
        security('settlement_verification_failed', { ticket: ticket.number, txid, error: error.message });
        return interaction.editReply(error.message);
      }
    }
    case 'health': {
      return interaction.reply({ embeds: [new EmbedBuilder().setTitle('Quantum-MM Health').setColor(colorsForUi().success).setDescription(`**Discord:** ${interaction.client.isReady() ? 'ready' : 'not ready'}\n**Guilds:** ${interaction.client.guilds.cache.size}\n**Active tickets:** ${Object.keys(store.snapshot.tickets).length}\n**Active monitors:** ${monitor.tasks.size}\n**Uptime:** ${Math.floor(process.uptime())} seconds`)] });
    }
    default:
      return interaction.reply(ephemeral('Unknown command.'));
  }
}

async function handleButton(interaction, context) {
  const { tickets, store } = context;
  const id = interaction.customId;
  if (id === componentIds.requestLtc || id === componentIds.requestUsdt) {
    const { requestModal } = await import('../ui/components.js');
    return interaction.showModal(requestModal(id === componentIds.requestLtc ? 'ltc' : 'usdt'));
  }

  const ticket = await requireTicket(interaction, tickets);
  if (!ticket) return;

  if (id === componentIds.deleteTicket) {
    if (!partyOrAdmin(interaction, ticket)) return reply(interaction, ephemeral('You cannot delete this ticket.'));
    if (FUNDED_STATUSES.has(ticket.status) && !isAdmin(interaction)) return reply(interaction, ephemeral('Only an administrator can delete a funded ticket.'));
    await interaction.deferReply({ ephemeral: true });
    await interaction.editReply('Deleting ticket and saving transcript...');
    await sleep(1500);
    await tickets.closeTicket(interaction.channel, ticket, `Ticket deleted by ${interaction.user.tag}`);
    return;
  }

  if (id === componentIds.roleSender || id === componentIds.roleReceiver) {
    if (!userIsParty(interaction, ticket)) return reply(interaction, ephemeral('Only the two traders can select roles.'));
    if (ticket.status !== 'roleSelection') return reply(interaction, ephemeral('Role selection is no longer active.'));
    if (String(ticket.senderId) === String(interaction.user.id) || String(ticket.receiverId) === String(interaction.user.id)) return reply(interaction, ephemeral('You already selected a role.'));
    const key = id === componentIds.roleSender ? 'senderId' : 'receiverId';
    if (ticket[key]) return reply(interaction, ephemeral('That role has already been selected.'));
    ticket[key] = interaction.user.id;
    const complete = Boolean(ticket.senderId && ticket.receiverId);
    store.addAudit('role_selected', { ticket: ticket.number, userId: interaction.user.id, role: key });
    await store.save();
    await interaction.update(roleSelectionPayload(ticket, complete));
    if (complete) await tickets.sendRoleConfirmation(interaction.channel, ticket);
    return;
  }

  if (id === componentIds.roleReset) {
    if (!partyOrAdmin(interaction, ticket)) return reply(interaction, ephemeral('You cannot reset this selection.'));
    if (ticket.status !== 'roleSelection') return reply(interaction, ephemeral('Role selection is no longer active.'));
    ticket.senderId = null; ticket.receiverId = null; ticket.roleConfirmed = [];
    await store.save();
    return interaction.update(roleSelectionPayload(ticket));
  }

  if (id === componentIds.rolesCorrect || id === componentIds.rolesIncorrect) {
    if (!userIsParty(interaction, ticket)) return reply(interaction, ephemeral('Only the two traders can confirm the roles.'));
    if (ticket.status !== 'roleConfirmation') return reply(interaction, ephemeral('This confirmation is no longer active.'));
    if (id === componentIds.rolesIncorrect) {
      ticket.status = 'roleResetting';
      await store.save();
      await interaction.update(roleConfirmationPayload(ticket, true));
      await interaction.followUp(simpleNotice(`❌ ${interaction.user} marked the roles as incorrect. Please select them again.`, colorsForUi().error));
      return tickets.sendRoleSelection(interaction.channel, ticket);
    }
    if (!ticket.roleConfirmed.includes(interaction.user.id)) ticket.roleConfirmed.push(interaction.user.id);
    const both = [ticket.senderId, ticket.receiverId].every((userId) => ticket.roleConfirmed.map(String).includes(String(userId)));
    if (both) ticket.status = 'roleConfirmationComplete';
    await store.save();
    await interaction.update(roleConfirmationPayload(ticket, both));
    await interaction.followUp(simpleNotice(`✅ ${interaction.user} confirmed the roles.`, colorsForUi().success));
    if (both) await tickets.sendUsdPrompt(interaction.channel, ticket);
    return;
  }

  if (id === componentIds.setUsd) {
    if (!isSender(interaction, ticket)) return reply(interaction, ephemeral('Only the sender can set the USD amount.'));
    if (ticket.status !== 'usdPrompt') return reply(interaction, ephemeral('The USD amount is no longer being set here.'));
    const { usdModal } = await import('../ui/components.js');
    return interaction.showModal(usdModal());
  }

  if (id === componentIds.usdCorrect || id === componentIds.usdIncorrect) {
    if (!userIsParty(interaction, ticket)) return reply(interaction, ephemeral('Only the two traders can confirm the amount.'));
    if (ticket.status !== 'usdConfirmation') return reply(interaction, ephemeral('This amount confirmation is no longer active.'));
    if (id === componentIds.usdIncorrect) {
      ticket.usdAmount = null; ticket.usdConfirmed = []; ticket.status = 'usdResetting';
      await store.save();
      await interaction.update(usdConfirmationPayload(ticket, true));
      await interaction.followUp(simpleNotice(`❌ ${interaction.user} marked the amount as incorrect.`, colorsForUi().error));
      return tickets.sendUsdPrompt(interaction.channel, ticket);
    }
    if (!ticket.usdConfirmed.includes(interaction.user.id)) ticket.usdConfirmed.push(interaction.user.id);
    const both = [ticket.senderId, ticket.receiverId].every((userId) => ticket.usdConfirmed.map(String).includes(String(userId)));
    if (both) ticket.status = 'usdConfirmationComplete';
    await store.save();
    await interaction.update(usdConfirmationPayload(ticket, both));
    await interaction.followUp(simpleNotice(`✅ ${interaction.user} confirmed the USD amount.`, colorsForUi().success));
    if (both) await tickets.sendPaymentInfo(interaction.channel, ticket);
    return;
  }

  if (id === componentIds.copyDetails) {
    if (!userIsParty(interaction, ticket)) return reply(interaction, ephemeral('Only the two traders can use this button.'));
    await interaction.update(paymentInfoPayload(ticket, true));
    return interaction.followUp({ content: `Deposit address:\n${ticket.depositAddress}\n\nRequired amount:\n${ticket.cryptoAmount} ${assetName(ticket)}`, ephemeral: true });
  }

  if (id === componentIds.release || id === componentIds.cancel) {
    if (!userIsParty(interaction, ticket)) return reply(interaction, ephemeral('Only the two traders can use this button.'));
    if (ticket.status !== 'trade') return reply(interaction, ephemeral('This trade is not ready for that action.'));
    if (id === componentIds.release) {
      if (!isSender(interaction, ticket)) return reply(interaction, ephemeral('Only the sender can release the escrow.'));
      ticket.status = 'releaseStarting';
      await store.save();
      await interaction.update(proceedPayload(ticket, true));
      return tickets.sendReleaseConfirmation(interaction.channel, ticket);
    }
    ticket.uncancelVotes = []; ticket.cancelVotes = []; ticket.status = 'cancellation';
    await store.save();
    await interaction.update(proceedPayload(ticket, true));
    const message = await interaction.channel.send(cancellationPayload(ticket));
    ticket.messages.cancellation = message.id;
    await store.save();
    return;
  }

  if (id === componentIds.uncancel || id === componentIds.confirmCancel) {
    if (!userIsParty(interaction, ticket)) return reply(interaction, ephemeral('Only the two traders can vote on cancellation.'));
    if (ticket.status !== 'cancellation') return reply(interaction, ephemeral('This cancellation vote is no longer active.'));
    const list = id === componentIds.uncancel ? ticket.uncancelVotes : ticket.cancelVotes;
    const other = id === componentIds.uncancel ? ticket.cancelVotes : ticket.uncancelVotes;
    if (!list.map(String).includes(String(interaction.user.id))) list.push(interaction.user.id);
    const index = other.findIndex((value) => String(value) === String(interaction.user.id));
    if (index >= 0) other.splice(index, 1);
    const parties = [ticket.senderId, ticket.receiverId].map(String);
    const uncancelDone = parties.every((userId) => ticket.uncancelVotes.map(String).includes(userId));
    const cancelDone = parties.every((userId) => ticket.cancelVotes.map(String).includes(userId));
    ticket.status = uncancelDone ? 'trade' : cancelDone ? 'cancelledPendingSettlement' : 'cancellation';
    await store.save();
    await interaction.update(cancellationPayload(ticket, uncancelDone || cancelDone));
    if (uncancelDone) {
      ticket.uncancelVotes = []; ticket.cancelVotes = [];
      await store.save();
      const proceed = ticket.messages.proceed ? await interaction.channel.messages.fetch(ticket.messages.proceed).catch(() => null) : null;
      if (proceed) await proceed.edit(proceedPayload(ticket)).catch(() => {});
      return interaction.followUp(simpleNotice('✅ **Trade Resumed**', colorsForUi().success));
    }
    if (cancelDone) return interaction.followUp(simpleNotice('❌ **Cancellation Confirmed**\n\nAn administrator must handle settlement or refund of any deposited funds before this ticket can close.', colorsForUi().error));
    return;
  }

  if (id === componentIds.releaseConfirm || id === componentIds.releaseBack) {
    if (!isSender(interaction, ticket)) return reply(interaction, ephemeral('Only the sender can use this button.'));
    if (ticket.status !== 'releaseConfirmation') return reply(interaction, ephemeral('This release confirmation is no longer active.'));
    if (id === componentIds.releaseBack) {
      ticket.status = 'trade'; ticket.releaseConfirmReady = false; ticket.releaseCountdownEnd = 0;
      await store.save();
      context.countdown?.cancel?.(ticket.channelId, 'release');
      await interaction.update(releaseConfirmationPayload(ticket, null, true));
      const proceed = ticket.messages.proceed ? await interaction.channel.messages.fetch(ticket.messages.proceed).catch(() => null) : null;
      if (proceed) await proceed.edit(proceedPayload(ticket)).catch(() => {});
      return;
    }
    if (!ticket.releaseConfirmReady && Date.now() < Number(ticket.releaseCountdownEnd)) return reply(interaction, ephemeral('Please wait for the confirmation countdown.'));
    ticket.releaseAuthorized = true; ticket.releaseConfirmReady = true; ticket.status = 'addressStarting';
    await store.save();
    context.countdown?.cancel?.(ticket.channelId, 'release');
    await interaction.update(releaseConfirmationPayload(ticket, null, true));
    return tickets.sendAddressPrompt(interaction.channel, ticket);
  }

  if (id === componentIds.enterAddress) {
    if (!isReceiver(interaction, ticket)) return reply(interaction, ephemeral('Only the receiver can enter the withdrawal address.'));
    if (ticket.status !== 'addressPrompt') return reply(interaction, ephemeral('This address prompt is no longer active.'));
    return interaction.showModal(addressModal(ticket));
  }

  if (id === componentIds.addressConfirm || id === componentIds.addressBack) {
    if (!isReceiver(interaction, ticket)) return reply(interaction, ephemeral('Only the receiver can use this button.'));
    if (ticket.status !== 'addressConfirmation') return reply(interaction, ephemeral('This address confirmation is no longer active.'));
    if (id === componentIds.addressBack) {
      ticket.receiverAddress = null; ticket.addressConfirmReady = false; ticket.addressCountdownEnd = 0; ticket.status = 'addressPrompt';
      await store.save();
      context.countdown?.cancel?.(ticket.channelId, 'address');
      await interaction.update({ components: addressConfirmationPayload(ticket, null, true).components });
      return tickets.sendAddressPrompt(interaction.channel, ticket);
    }
    if (!ticket.addressConfirmReady && Date.now() < Number(ticket.addressCountdownEnd)) return reply(interaction, ephemeral('Please wait for the confirmation countdown.'));
    ticket.addressConfirmReady = true; ticket.status = 'settlementPending';
    await store.save();
    context.countdown?.cancel?.(ticket.channelId, 'address');
    await interaction.update({ components: addressConfirmationPayload(ticket, null, true).components });
    const sending = await interaction.channel.send(simpleNotice('🔄 · **Sending...**'));
    await sleep(1500);
    await sending.delete().catch(() => {});
    if (context.config.settlementMode === 'simulation') {
      const fake = `SIMULATION-${crypto.randomBytes(24).toString('hex').toUpperCase()}`;
      return tickets.finalizeWithdrawal(ticket, fake, ticket.depositAmount, true);
    }
    await interaction.channel.send((await import('../ui/components.js')).settlementPendingPayload(ticket));
    if (!await tickets.sendSettlementRequest(ticket)) await interaction.channel.send(simpleNotice('❌ · **The settlement channel could not be found. An administrator must resolve the configuration.**', colorsForUi().error));
    return;
  }

  if (id === componentIds.closeTicket) {
    if (!partyOrAdmin(interaction, ticket)) return reply(interaction, ephemeral('You cannot close this ticket.'));
    if (ticket.status !== 'completed') return reply(interaction, ephemeral('This ticket has not been completed yet.'));
    await interaction.deferUpdate();
    await tickets.sendCompletionOutputs(ticket);
    if (!ticket.completedChannelSent) return interaction.followUp(ephemeral('The completed transaction log could not be saved, so the ticket was not closed.'));
    await interaction.followUp('Closing ticket and saving transcript...');
    await sleep(2500);
    return tickets.closeTicket(interaction.channel, ticket, `Completed ticket closed by ${interaction.user.tag}`);
  }
}

async function handleModal(interaction, context) {
  const { tickets, store } = context;
  if (interaction.customId === 'qmm:modal:request:ltc' || interaction.customId === 'qmm:modal:request:usdt') {
    await interaction.deferReply({ ephemeral: true });
    const type = interaction.customId.endsWith(':ltc') ? 'ltc' : 'usdt';
    const trader = await tickets.resolveTrader(interaction.guild, interaction.fields.getTextInputValue('trader'));
    if (!trader) return interaction.editReply('I could not find that trader. Use their exact username, mention, or ID.');
    if (trader.user.bot) return interaction.editReply('The trader cannot be a bot.');
    if (trader.id === interaction.user.id) return interaction.editReply('You cannot open a ticket with yourself.');
    try {
      const { channel, ticket } = await tickets.createTicket({ guild: interaction.guild, opener: interaction.member, trader, type, openerSide: interaction.fields.getTextInputValue('openerSide'), traderSide: interaction.fields.getTextInputValue('traderSide') });
      return interaction.editReply(`**Ticket ${ticket.number} created!** → ${channel}`);
    } catch (error) {
      logger.error('Ticket creation failed', { error: error.message });
      return interaction.editReply(`Ticket creation failed: ${error.message}`);
    }
  }

  const ticket = await requireTicket(interaction, tickets);
  if (!ticket) return;
  if (interaction.customId === 'qmm:modal:usd') {
    if (!isSender(interaction, ticket)) return reply(interaction, ephemeral('Only the sender can set the USD amount.'));
    if (ticket.status !== 'usdPrompt') return reply(interaction, ephemeral('This USD amount prompt is no longer active.'));
    const amount = parsePositiveDecimal(interaction.fields.getTextInputValue('amount'))?.toDecimalPlaces(2);
    if (!amount || amount.lte(0)) return reply(interaction, ephemeral('Enter a valid USD amount.'));
    ticket.usdAmount = amount.toFixed(2); ticket.usdConfirmed = [];
    await store.save();
    const old = ticket.messages.usdPrompt ? await interaction.channel.messages.fetch(ticket.messages.usdPrompt).catch(() => null) : null;
    if (old) await old.edit({ components: old.components.map((row) => ({ ...row.toJSON(), components: row.components.map((component) => ({ ...component.toJSON(), disabled: true })) })) }).catch(() => {});
    await interaction.reply(ephemeral('USD amount submitted.'));
    return tickets.sendUsdConfirmation(interaction.channel, ticket);
  }

  if (interaction.customId === 'qmm:modal:address') {
    if (!isReceiver(interaction, ticket)) return reply(interaction, ephemeral('Only the receiver can submit the withdrawal address.'));
    if (ticket.status !== 'addressPrompt') return reply(interaction, ephemeral('This address prompt is no longer active.'));
    const address = interaction.fields.getTextInputValue('address').trim();
    if (ticket.type === 'usdt' && !/^0x[a-fA-F0-9]{40}$/.test(address)) return reply(interaction, ephemeral('Enter a valid BSC address.'));
    if (ticket.type === 'ltc' && !/^(ltc1|[LM3])[a-zA-Z0-9]{20,70}$/.test(address)) return reply(interaction, ephemeral('Enter a valid Litecoin address.'));
    ticket.receiverAddress = address; await store.save();
    const old = ticket.messages.addressPrompt ? await interaction.channel.messages.fetch(ticket.messages.addressPrompt).catch(() => null) : null;
    if (old) await old.edit({ components: old.components.map((row) => ({ ...row.toJSON(), components: row.components.map((component) => ({ ...component.toJSON(), disabled: true })) })) }).catch(() => {});
    await interaction.reply(ephemeral('Address submitted.'));
    return tickets.sendAddressConfirmation(interaction.channel, ticket);
  }
}

export function registerInteractionHandler(client, context) {
  client.on(Events.InteractionCreate, async (interaction) => {
    try {
      if (interaction.isChatInputCommand()) await handleCommand(interaction, context);
      else if (interaction.isButton()) await handleButton(interaction, context);
      else if (interaction.isModalSubmit()) await handleModal(interaction, context);
    } catch (error) {
      logger.error('Interaction handler failed', { command: interaction.commandName, customId: interaction.customId, error: error.message });
      try {
        await reply(interaction, ephemeral('An unexpected error occurred while processing this interaction.'));
      } catch { /* Discord may already have expired the interaction. */ }
    }
  });
}
