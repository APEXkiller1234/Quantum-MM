import Decimal from 'decimal.js';

export const DOT = '﹒';
export const ZERO_WIDTH = '\u200b';

export function decimal(value, fallback = new Decimal(0)) {
  try {
    const result = new Decimal(String(value));
    return result.isFinite() ? result : fallback;
  } catch {
    return fallback;
  }
}

export function parsePositiveDecimal(value) {
  const cleaned = String(value ?? '').replaceAll('$', '').replaceAll(',', '').trim();
  try {
    const amount = new Decimal(cleaned);
    return amount.isFinite() && amount.gt(0) ? amount : null;
  } catch {
    return null;
  }
}

export function money(value) {
  return `$${decimal(value).toDecimalPlaces(2).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',')}`;
}

export function assetName(ticketOrType) {
  return (ticketOrType?.type ?? ticketOrType) === 'ltc' ? 'LTC' : 'USDT';
}

export function assetLongName(ticket) {
  return ticket.type === 'ltc' ? 'Litecoin' : 'USDT [BEP-20]';
}

export function cryptoAmount(ticket, value = ticket.depositAmount ?? ticket.cryptoAmount ?? 0) {
  const places = ticket.type === 'ltc' ? 8 : 2;
  return decimal(value).toDecimalPlaces(places, Decimal.ROUND_DOWN).toFixed(places).replace(/0+$/, '').replace(/\.$/, '') || '0';
}

export function requiredCryptoDisplay(ticket) {
  const places = ticket.type === 'ltc' ? 5 : 2;
  return decimal(ticket.cryptoAmount ?? 0).toDecimalPlaces(places, Decimal.ROUND_DOWN).toFixed(places).replace(/0+$/, '').replace(/\.$/, '') || '0';
}

export function requiredCryptoDecimal(ticket) {
  return decimal(ticket.cryptoAmount ?? 0);
}

export function normalizeTxid(txid) {
  return String(txid ?? '').trim().toLowerCase();
}

export function isManualReference(txid) {
  return String(txid ?? '').toUpperCase().startsWith('MANUAL-');
}

export function isSimulationReference(txid) {
  return String(txid ?? '').toUpperCase().startsWith('SIMULATION-');
}

export function shortTxid(txid) {
  const value = String(txid ?? '');
  return value.length <= 23 ? value : `${value.slice(0, 10)}...${value.slice(-10)}`;
}

export function txLink(txid, type) {
  return type === 'ltc' ? `https://live.blockcypher.com/ltc/tx/${encodeURIComponent(txid)}/` : `https://bscscan.com/tx/${encodeURIComponent(txid)}`;
}

export function txDisplay(ticket, txid) {
  if (!txid) return '`N/A`';
  if (ticket.manualDepositOverride && txid === ticket.depositTxid) return `\`${txid}\``;
  if (isManualReference(txid) || isSimulationReference(txid)) return `\`${txid}\``;
  return `[\`${shortTxid(txid)}\`](${txLink(txid, ticket.type)})`;
}

export function cleanChannelName(value) {
  const ascii = String(value ?? '').normalize('NFKD').replace(/[^\x00-\x7F]/g, '');
  return ascii.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 45) || 'user';
}

export function safeCodeText(value) {
  return String(value ?? '').replaceAll('```', '~~~').trim();
}

export function channelMention(id) {
  return id ? `<#${id}>` : '`CHANNEL NOT SET`';
}

export function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function userIsParty(interaction, ticket) {
  return [ticket.openerId, ticket.traderId].map(String).includes(String(interaction.user.id));
}

export function isSender(interaction, ticket) {
  return String(ticket.senderId) === String(interaction.user.id);
}

export function isReceiver(interaction, ticket) {
  return String(ticket.receiverId) === String(interaction.user.id);
}

export function isAdmin(interaction) {
  return Boolean(interaction.memberPermissions?.has?.('Administrator'));
}
