import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle
} from 'discord.js';
import { config } from '../config.js';
import { assetLongName, assetName, channelMention, cryptoAmount, money, requiredCryptoDisplay, safeCodeText, txDisplay, ZERO_WIDTH } from '../utils/format.js';

export const componentIds = Object.freeze({
  requestLtc: 'qmm:request:ltc',
  requestUsdt: 'qmm:request:usdt',
  deleteTicket: 'qmm:ticket:delete',
  roleSender: 'qmm:role:sender',
  roleReceiver: 'qmm:role:receiver',
  roleReset: 'qmm:role:reset',
  rolesCorrect: 'qmm:roles:correct',
  rolesIncorrect: 'qmm:roles:incorrect',
  setUsd: 'qmm:usd:set',
  usdCorrect: 'qmm:usd:correct',
  usdIncorrect: 'qmm:usd:incorrect',
  copyDetails: 'qmm:payment:copy',
  release: 'qmm:release:start',
  cancel: 'qmm:cancel:start',
  uncancel: 'qmm:cancel:uncancel',
  confirmCancel: 'qmm:cancel:confirm',
  releaseConfirm: 'qmm:release:confirm',
  releaseBack: 'qmm:release:back',
  enterAddress: 'qmm:address:enter',
  addressConfirm: 'qmm:address:confirm',
  addressBack: 'qmm:address:back',
  closeTicket: 'qmm:ticket:close'
});

const colors = Object.freeze({
  neutral: 0xbfbfbf,
  success: 0x86ef93,
  error: 0xdb504c,
  warning: 0xf3aa3c,
  usdt: 0x509f7d,
  purple: 0x5b65ea
});

const unicode = Object.freeze({ money: '💵', scroll: '📜', warning: '⚠️', lock: '🔒', x: '❌', tick: '✅', loading: '🔄', wave: '👋', shield: '🛡️' });

function configuredEmoji(value, fallback = '') {
  return value?.trim() || fallback;
}

function button(id, label, style, emoji, disabled = false) {
  const builder = new ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style).setDisabled(disabled);
  const value = configuredEmoji(emoji);
  if (value) {
    const match = value.match(/^<(a?):([\w~]+):(\d+)>$/);
    builder.setEmoji(match ? { animated: Boolean(match[1]), name: match[2], id: match[3] } : { name: value });
  }
  return builder;
}

function row(...children) {
  return new ActionRowBuilder().addComponents(children);
}

function mention(id) {
  return id ? `<@${id}>` : '...';
}

function baseEmbed(description, color = colors.neutral) {
  return new EmbedBuilder().setDescription(description).setColor(color);
}

export function panelPayload() {
  const biggest = config.marketing.biggestTradeMessageUrl
    ? `[Biggest Trade](${config.marketing.biggestTradeMessageUrl})`
    : 'Biggest Trade';
  const embed = new EmbedBuilder()
    .setTitle('Jace’s Auto Middleman')
    .setDescription(`**Paid Service**\n\nRead our ToS before using the bot: ${channelMention(config.channels.tos)}\n\nUse the buttons below to open a private, guided trade ticket.`)
    .setColor(colors.neutral)
    .addFields(
      { name: 'Fees', value: 'Deals $250+: **$1.50**\nDeals under $250: **$0.50**\nDeals under $50: **FREE**', inline: false },
      { name: 'Security checklist', value: 'Confirm the trader, amount, deposit address, and payout address. Staff will never ask you to release a trade early.', inline: false },
      { name: biggest, value: `${channelMention(config.channels.completed)} · **$${config.marketing.biggestTradeUsd.toLocaleString('en-US', { maximumFractionDigits: 0 })}**`, inline: false }
    )
    .setFooter({ text: 'Quantum-MM · deposits are monitored publicly; payouts are settled by an administrator' });

  const tutorial = new ButtonBuilder().setLabel('Tutorial').setStyle(ButtonStyle.Link).setURL(config.marketing.tutorialUrl);
  return { embeds: [embed], components: [row(tutorial), row(button(componentIds.requestLtc, 'Request LTC', ButtonStyle.Primary, config.emojis.ltc || 'Ł'), button(componentIds.requestUsdt, 'Request USDT · BEP-20', ButtonStyle.Success, config.emojis.usdt || '₮'))] };
}

export function requestModal(type) {
  const asset = type === 'ltc' ? 'LTC' : 'USDT';
  return new ModalBuilder()
    .setCustomId(`qmm:request:${type}`)
    .setTitle(`Request ${asset} Middleman`)
    .addComponents(
      row(new TextInputBuilder().setCustomId('trader').setLabel('Trader username, mention, or ID').setPlaceholder('e.g. kookie.py or 693059117761429610').setStyle(TextInputStyle.Short).setRequired(true).setMinLength(2).setMaxLength(100)),
      row(new TextInputBuilder().setCustomId('openerSide').setLabel('What are you giving?').setStyle(TextInputStyle.Paragraph).setRequired(true).setMinLength(2).setMaxLength(1000)),
      row(new TextInputBuilder().setCustomId('traderSide').setLabel('What is your trader giving?').setStyle(TextInputStyle.Paragraph).setRequired(true).setMinLength(2).setMaxLength(1000))
    );
}

export function usdModal() {
  return new ModalBuilder()
    .setCustomId('qmm:modal:usd')
    .setTitle('Set USD Amount')
    .addComponents(row(new TextInputBuilder().setCustomId('amount').setLabel('Amount in USD').setPlaceholder('e.g. 435.20').setStyle(TextInputStyle.Short).setRequired(true).setMinLength(1).setMaxLength(20)));
}

export function addressModal(ticket) {
  const asset = assetName(ticket);
  return new ModalBuilder()
    .setCustomId('qmm:modal:address')
    .setTitle(`Your ${asset} Address`)
    .addComponents(row(new TextInputBuilder().setCustomId('address').setLabel(`${asset} withdrawal address`).setPlaceholder(`Enter your ${asset} address`).setStyle(TextInputStyle.Short).setRequired(true).setMinLength(10).setMaxLength(120)));
}

export function ticketOpenerPayload(opener, trader, ticket) {
  const embed = new EmbedBuilder()
    .setTitle('Jace’s Auto Middleman Service')
    .setDescription(`Make sure to follow every step and read the instructions thoroughly.\n\nExplicitly state the trade details if anything below is inaccurate. By using this bot, you agree to our ToS ${channelMention(config.channels.tos)}.`)
    .setColor(colors.neutral)
    .addFields(
      { name: `${mention(opener.id)}’s side`, value: `\`\`\`\n${safeCodeText(ticket.openerSide)}\n\`\`\``, inline: true },
      { name: `${mention(trader.id)}’s side`, value: `\`\`\`\n${safeCodeText(ticket.traderSide)}\n\`\`\``, inline: true },
      { name: 'Ticket safeguards', value: 'Only the two traders and the bot can see this channel. Use **Delete Ticket** to close an unfunded request or ask an administrator for help.', inline: false }
    );
  return { content: `${mention(opener.id)} ${mention(trader.id)}`, embeds: [embed], components: [row(button(componentIds.deleteTicket, 'Delete Ticket', ButtonStyle.Danger, config.emojis.animatedX || unicode.x))], allowedMentions: { users: true, roles: false, everyone: false } };
}

export function roleSelectionPayload(ticket, disabled = false) {
  const embed = baseEmbed(`${configuredEmoji(config.emojis.roleShield, unicode.shield)} · **Select your role**\n\n• **Sender**: sending ${assetName(ticket)} to the bot.\n• **Receiver**: receiving ${assetName(ticket)} later from the bot.`, colors.neutral)
    .addFields({ name: 'Sender', value: mention(ticket.senderId), inline: true }, { name: 'Receiver', value: mention(ticket.receiverId), inline: true });
  return { embeds: [embed], components: [row(button(componentIds.roleSender, 'Sender', ButtonStyle.Primary, undefined, disabled || Boolean(ticket.senderId)), button(componentIds.roleReceiver, 'Receiver', ButtonStyle.Primary, undefined, disabled || Boolean(ticket.receiverId)), button(componentIds.roleReset, 'Reset', ButtonStyle.Danger, undefined, disabled))] };
}

export function roleConfirmationPayload(ticket, disabled = false) {
  const embed = baseEmbed(`${configuredEmoji(config.emojis.blueLoading, unicode.loading)} · **Are these roles correct?**\n\nMake sure the right person is the sender and receiver. If not, click **Incorrect**.`, colors.neutral)
    .addFields({ name: 'Sender', value: mention(ticket.senderId), inline: true }, { name: 'Receiver', value: mention(ticket.receiverId), inline: true });
  return { content: `${mention(ticket.senderId)} ${mention(ticket.receiverId)}`, embeds: [embed], components: [row(button(componentIds.rolesCorrect, 'Correct', ButtonStyle.Success, config.emojis.greenTick || unicode.tick, disabled), button(componentIds.rolesIncorrect, 'Incorrect', ButtonStyle.Danger, config.emojis.animatedX || unicode.x, disabled))], allowedMentions: { users: true, roles: false, everyone: false } };
}

export function simpleNotice(description, color = colors.neutral) {
  return { embeds: [baseEmbed(description, color)] };
}

export function usdPromptPayload() {
  return { content: 'The sender must set the USD value for both traders to confirm.', embeds: [baseEmbed(`${unicode.money} · **Set the amount in USD value**`, colors.neutral)], components: [row(button(componentIds.setUsd, 'Set USD Amount', ButtonStyle.Primary))] };
}

export function usdConfirmationPayload(ticket, disabled = false) {
  const embed = baseEmbed(`${configuredEmoji(config.emojis.blueLoading, unicode.loading)} · **USD amount set to \`${money(ticket.usdAmount)}\`**\n\nPlease confirm the USD amount.`, colors.neutral);
  return { content: `${mention(ticket.senderId)} ${mention(ticket.receiverId)}`, embeds: [embed], components: [row(button(componentIds.usdCorrect, 'Correct', ButtonStyle.Success, config.emojis.greenTick || unicode.tick, disabled), button(componentIds.usdIncorrect, 'Incorrect', ButtonStyle.Danger, config.emojis.animatedX || unicode.x, disabled))], allowedMentions: { users: true, roles: false, everyone: false } };
}

export function paymentInfoPayload(ticket, disabled = false) {
  const asset = assetName(ticket);
  const embed = baseEmbed(`${unicode.scroll} · **Payment Information**\n\nSend the **EXACT** amount in ${asset}.`, colors.neutral)
    .addFields(
      { name: 'USD Amount', value: `\`${money(ticket.usdAmount)}\``, inline: true },
      { name: `${configuredEmoji(ticket.type === 'ltc' ? config.emojis.ltc : config.emojis.usdt, asset === 'LTC' ? 'Ł' : '₮')} ${asset} Amount`, value: `\`${requiredCryptoDisplay(ticket)}\``, inline: true },
      { name: 'Payment Address', value: `\`${ticket.depositAddress}\``, inline: false },
      { name: ZERO_WIDTH, value: ticket.type === 'ltc' ? `**Current LTC Price: ${money(ticket.cryptoPrice)}**\n` : '**Network: BSC (BEP-20)**\n' + '**This ticket will close within 20 minutes if no transaction is detected.**', inline: false }
    );
  if (ticket.type === 'ltc') embed.spliceFields(3, 1, { name: ZERO_WIDTH, value: `**Current LTC Price: ${money(ticket.cryptoPrice)}**\n**This ticket will close within 20 minutes if no transaction is detected.**`, inline: false });
  return { content: `${mention(ticket.senderId)} Send the ${asset} to the following address.`, embeds: [embed], components: [row(button(componentIds.copyDetails, 'Copy Details', ButtonStyle.Primary, undefined, disabled))], allowedMentions: { users: true, roles: false, everyone: false } };
}

export function transactionDetectedPayload(ticket) {
  const asset = assetName(ticket);
  const required = requiredCryptoDisplay(ticket);
  const amount = cryptoAmount(ticket, ticket.depositAmount || ticket.cryptoAmount || 0);
  const needed = ticket.type === 'ltc' ? config.ltcConfirmations : config.usdtConfirmations;
  const embed = baseEmbed(`${unicode.warning} · **Transaction Detected**\n\nThe transaction is **unconfirmed** and waiting for ${needed} confirmation${needed === 1 ? '' : 's'}.`, colors.warning)
    .addFields(
      { name: ticket.manualDepositOverride ? 'Manual Deposit Reference' : 'Transaction', value: `${txDisplay(ticket, ticket.depositTxid)} (${amount} ${asset})`, inline: false },
      { name: 'Amount Received', value: `\`${amount}\` ${asset} (${money(ticket.usdAmount)})`, inline: true },
      { name: 'Required Amount', value: `\`${required}\` ${asset} (${money(ticket.usdAmount)})`, inline: true },
      { name: ZERO_WIDTH, value: '**You will be notified when the transaction is confirmed.**', inline: false }
    );
  return { embeds: [embed] };
}

export function transactionConfirmedPayload(ticket) {
  const asset = assetName(ticket);
  const amount = cryptoAmount(ticket, ticket.depositAmount || ticket.cryptoAmount || 0);
  return { embeds: [baseEmbed(`${configuredEmoji(config.emojis.greenTick, unicode.tick)} · **Transaction Confirmed!**`, colors.success).addFields({ name: ticket.manualDepositOverride ? 'Manual Deposit Reference' : 'Transaction', value: `${txDisplay(ticket, ticket.depositTxid)} (${amount} ${asset})`, inline: false }, { name: 'Total Amount Received', value: `\`${amount}\` ${asset} (${money(ticket.usdAmount)})`, inline: false })] };
}

export function proceedPayload(ticket, disabled = false) {
  const asset = assetName(ticket);
  const embed = baseEmbed(`${configuredEmoji(config.emojis.greenTick, unicode.tick)} · **You may proceed with your trade.**\n\n> **1. ${mention(ticket.receiverId)} Give your trader the items or payment you agreed on.**\n\n> **2. ${mention(ticket.senderId)} Once you have received your items, click **Release** so your trader can claim the ${asset}.**`, colors.success);
  return { content: `${mention(ticket.senderId)} ${mention(ticket.receiverId)}`, embeds: [embed], components: [row(button(componentIds.release, 'Release', ButtonStyle.Success, undefined, disabled), button(componentIds.cancel, 'Cancel', ButtonStyle.Secondary, undefined, disabled))], allowedMentions: { users: true, roles: false, everyone: false } };
}

export function cancellationPayload(ticket, disabled = false) {
  const users = (ids) => ids?.length ? ids.map(mention).join('\n') : 'None yet';
  const embed = baseEmbed(`${unicode.warning} **Cancellation Requested**\n\nSelect **Uncancel** to continue or **Confirm Cancellation** to cancel.`, colors.warning)
    .addFields({ name: 'Agreed to Uncancel', value: users(ticket.uncancelVotes), inline: false }, { name: 'Confirmed Cancellation', value: users(ticket.cancelVotes), inline: false }, { name: ZERO_WIDTH, value: '**Both traders must select the same option.**', inline: false });
  return { content: `${mention(ticket.senderId)} ${mention(ticket.receiverId)}`, embeds: [embed], components: [row(button(componentIds.uncancel, 'Uncancel', ButtonStyle.Secondary, undefined, disabled), button(componentIds.confirmCancel, 'Confirm Cancellation', ButtonStyle.Danger, undefined, disabled))], allowedMentions: { users: true, roles: false, everyone: false } };
}

export function releaseConfirmationPayload(ticket, countdown = null, disabled = false) {
  const asset = assetName(ticket);
  const label = countdown === null ? 'Confirm' : `Confirm (${countdown})`;
  const embed = baseEmbed(`${unicode.warning} **Are you sure you want to release the ${asset}?**\n\nConfirming gives your trader permission to withdraw the ${asset}.\n\n**Staff will never ask you to release or cancel.**`, colors.warning);
  return { content: mention(ticket.senderId), embeds: [embed], components: [row(button(componentIds.releaseConfirm, label, ButtonStyle.Success, undefined, disabled || countdown !== null), button(componentIds.releaseBack, 'Back', ButtonStyle.Secondary, undefined, disabled))], allowedMentions: { users: true, roles: false, everyone: false } };
}

export function addressPromptPayload(ticket, disabled = false) {
  const asset = assetName(ticket);
  return { content: mention(ticket.receiverId), embeds: [baseEmbed(`${configuredEmoji(ticket.type === 'ltc' ? config.emojis.ltc : config.emojis.usdt, asset === 'LTC' ? 'Ł' : '₮')} · **What’s Your ${asset}${ticket.type === 'usdt' ? ' [BEP-20]' : ''} Address?**\n\nMake sure to paste your correct withdrawal address.`, colors.neutral)], components: [row(button(componentIds.enterAddress, `Enter Your ${asset} Address`, ButtonStyle.Primary, undefined, disabled))], allowedMentions: { users: true, roles: false, everyone: false } };
}

export function addressConfirmationPayload(ticket, countdown = null, disabled = false) {
  const label = countdown === null ? 'Confirm' : `Confirm (${countdown})`;
  const embed = baseEmbed(`${unicode.warning} · **Confirm Address**\n\n> **Address:** \`${ticket.receiverAddress}\`\n\nClick **Confirm** to send ${assetName(ticket)} or **Back** to change it.`, colors.warning);
  return { content: mention(ticket.receiverId), embeds: [embed], components: [row(button(componentIds.addressConfirm, label, ButtonStyle.Success, undefined, disabled || countdown !== null), button(componentIds.addressBack, 'Back', ButtonStyle.Secondary, undefined, disabled))], allowedMentions: { users: true, roles: false, everyone: false } };
}

export function sendingPayload() {
  return { embeds: [baseEmbed(`${configuredEmoji(config.emojis.load, unicode.loading)} · **Sending...**`, colors.neutral)] };
}

export function settlementPendingPayload(ticket) {
  return { embeds: [baseEmbed(`${configuredEmoji(config.emojis.blueLoading, unicode.loading)} · **Settlement Pending**\n\nThe ${assetName(ticket)} release was authorized and the destination address was confirmed. The payout is waiting to be settled by an administrator.`, colors.warning)] };
}

export function settlementRequestPayload(ticket) {
  const embed = new EmbedBuilder().setTitle(`Settlement Request · ${ticket.number}`).setDescription(`Ticket: <#${ticket.channelId}>`).setColor(colors.warning).addFields(
    { name: 'Sender', value: mention(ticket.senderId), inline: true },
    { name: 'Receiver', value: mention(ticket.receiverId), inline: true },
    { name: 'USD Value', value: money(ticket.usdAmount), inline: true },
    { name: 'Asset', value: assetLongName(ticket), inline: true },
    { name: 'Amount Received', value: `${cryptoAmount(ticket, ticket.depositAmount)} ${assetName(ticket)}`, inline: true },
    { name: 'Receiver Address', value: `\`${ticket.receiverAddress}\``, inline: false },
    { name: ticket.manualDepositOverride ? 'Manual Deposit Reference' : 'Deposit Transaction', value: txDisplay(ticket, ticket.depositTxid), inline: false },
    { name: 'Settlement Command', value: `\`/settle ticket_number:${ticket.number} payout_txid:<transaction> payout_amount:<amount>\``, inline: false }
  ).setTimestamp();
  return { embeds: [embed] };
}

export function withdrawalSuccessPayload(ticket) {
  return { content: mention(ticket.receiverId), embeds: [baseEmbed(`${configuredEmoji(config.emojis.greenTick, unicode.tick)} · **Withdrawal Successful**\n\nUse /setprivacy to control your identity in ${channelMention(config.channels.completed)}.`, colors.neutral).addFields({ name: 'Transaction', value: txDisplay(ticket, ticket.payoutTxid), inline: true }, { name: 'Amount Sent', value: `\`${cryptoAmount(ticket, ticket.payoutAmount)}\` ${assetName(ticket)} (${money(ticket.usdAmount)})`, inline: true })], components: [row(button(componentIds.closeTicket, 'Close Ticket', ButtonStyle.Danger, unicode.lock))], allowedMentions: { users: true, roles: false, everyone: false } };
}

export function completedPayload(ticket) {
  const senderPrivate = configStorePrivacy(ticket.senderId);
  const receiverPrivate = configStorePrivacy(ticket.receiverId);
  const embed = baseEmbed(`${configuredEmoji(ticket.type === 'ltc' ? config.emojis.ltc : config.emojis.usdt, assetName(ticket) === 'LTC' ? 'Ł' : '₮')} · **Trade Completed**\n\n\`${cryptoAmount(ticket, ticket.payoutAmount)}\` ${assetName(ticket)} (${money(ticket.usdAmount)} USD)`, colors.neutral)
    .addFields({ name: 'Sender', value: senderPrivate ? '`Anonymous`' : mention(ticket.senderId), inline: true }, { name: 'Receiver', value: receiverPrivate ? '`Anonymous`' : mention(ticket.receiverId), inline: true }, { name: 'Transaction ID', value: txDisplay(ticket, ticket.payoutTxid), inline: false })
    .setTimestamp();
  return { embeds: [embed] };
}

// The UI module is deliberately independent from persistence; this small hook is replaced by TicketService at runtime.
let privacyLookup = () => true;
export function setPrivacyLookup(callback) { privacyLookup = callback; }
function configStorePrivacy(userId) { return Boolean(privacyLookup(String(userId))); }

export function demoCompletedPayload(sample, ltcPrice) {
  const amount = sample.amountLtc.toDecimalPlaces(8, 1).toFixed(8).replace(/0+$/, '').replace(/\.$/, '') || '0';
  const usd = ltcPrice ? sample.amountLtc.times(ltcPrice).toDecimalPlaces(2).toFixed(2) : '0.00';
  return { embeds: [new EmbedBuilder().setDescription(`Ł · **Demonstration Activity — not an escrow transaction**\n\n\`${amount}\` LTC (${money(usd)} USD)`).setColor(colors.neutral).addFields({ name: 'Sender', value: '`Demo`', inline: true }, { name: 'Receiver', value: '`Demo`', inline: true }, { name: 'Transaction ID', value: `[\`${sample.txid.slice(0, 10)}...\`](https://live.blockcypher.com/ltc/tx/${sample.txid}/)`, inline: false }).setFooter({ text: 'Public blockchain sample used for demonstration only' }).setTimestamp()] };
}

export function transcriptLogPayload(ticket, reason) {
  return { embeds: [new EmbedBuilder().setTitle(`Ticket ${ticket.number} Transcript`).setDescription(`Created: <t:${Math.floor(ticket.createdAt / 1000)}:F>\nClosed: <t:${Math.floor(Date.now() / 1000)}:F>\nReason: **${safeCodeText(reason)}**`).setColor(ticket.status === 'completed' ? colors.success : colors.neutral).addFields(
    { name: 'Opener', value: `${mention(ticket.openerId)}\nID: \`${ticket.openerId}\`\n${safeCodeText(ticket.openerSide)}`, inline: true },
    { name: 'Trader', value: `${mention(ticket.traderId)}\nID: \`${ticket.traderId}\`\n${safeCodeText(ticket.traderSide)}`, inline: true },
    { name: 'Trade Summary', value: `Asset: **${assetLongName(ticket)}**\nSender: ${mention(ticket.senderId)}\nReceiver: ${mention(ticket.receiverId)}\nUSD value: **${money(ticket.usdAmount || 0)}**\nAmount received: **${cryptoAmount(ticket, ticket.depositAmount || 0)} ${assetName(ticket)}**\nEscrow address: \`${ticket.depositAddress || 'N/A'}\`\nDeposit reference: \`${ticket.depositTxid || 'N/A'}\`\nReceiver payout address: \`${ticket.receiverAddress || 'N/A'}\`\nAmount sent: **${cryptoAmount(ticket, ticket.payoutAmount || 0)} ${assetName(ticket)}**\nPayout transaction: \`${ticket.payoutTxid || 'N/A'}\``, inline: false }
  )] };
}

export function colorsForUi() { return colors; }
