import { PermissionFlagsBits, REST, Routes, SlashCommandBuilder } from 'discord.js';
import { config } from './config.js';

export const commandDefinitions = [
  new SlashCommandBuilder().setName('panel').setDescription('Send the Quantum-MM middleman panel').setDefaultMemberPermissions(PermissionFlagsBits.Administrator.toString()),
  new SlashCommandBuilder().setName('stats').setDescription('View a user’s middleman stats').addUserOption((option) => option.setName('user').setDescription('User whose stats you want to view').setRequired(true)),
  new SlashCommandBuilder().setName('leaderboard').setDescription('Show the most active traders').addIntegerOption((option) => option.setName('limit').setDescription('Number of users to show').setMinValue(3).setMaxValue(10).setRequired(false)),
  new SlashCommandBuilder().setName('setprivacy').setDescription('Control whether completed trades display your user').addBooleanOption((option) => option.setName('private').setDescription('Hide your identity in completed-trade posts').setRequired(true)),
  new SlashCommandBuilder().setName('ticket-info').setDescription('View the current middleman ticket summary').addIntegerOption((option) => option.setName('ticket_number').setDescription('Ticket number').setRequired(true)),
  new SlashCommandBuilder().setName('mark-deposit').setDescription('Manually show or confirm a deposit state').addIntegerOption((option) => option.setName('ticket_number').setDescription('Ticket number').setRequired(true)).addStringOption((option) => option.setName('amount').setDescription('Amount of LTC or USDT received').setRequired(true)).addIntegerOption((option) => option.setName('confirmation').setDescription('0 for unconfirmed, 1 or more for confirmed').setMinValue(0).setMaxValue(100000).setRequired(true)),
  new SlashCommandBuilder().setName('settle').setDescription('Verify and record a completed payout').setDefaultMemberPermissions(PermissionFlagsBits.Administrator.toString()).addIntegerOption((option) => option.setName('ticket_number').setDescription('Ticket number').setRequired(true)).addStringOption((option) => option.setName('payout_txid').setDescription('Blockchain payout transaction ID').setRequired(true)).addStringOption((option) => option.setName('payout_amount').setDescription('Amount sent to the receiver').setRequired(true)),
  new SlashCommandBuilder().setName('health').setDescription('Show bot and monitor health')
].map((command) => command.toJSON());

export async function registerCommands() {
  const rest = new REST({ version: '10' }).setToken(config.discord.token);
  const route = config.discord.guildId
    ? Routes.applicationGuildCommands(config.discord.clientId, config.discord.guildId)
    : Routes.applicationCommands(config.discord.clientId);
  await rest.put(route, { body: commandDefinitions });
  console.log(`Registered ${commandDefinitions.length} slash commands ${config.discord.guildId ? `in guild ${config.discord.guildId}` : 'globally'}.`);
}
