import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';

function defaultData(startingNumber) {
  return {
    schemaVersion: 2,
    nextTicketNumber: startingNumber,
    tickets: {},
    stats: {},
    privacy: {},
    claimedDepositTxids: {},
    audit: []
  };
}

function camelCaseKey(key) {
  return String(key).replace(/_([a-z])/g, (_, character) => character.toUpperCase());
}

function migrateLegacyKeys(value) {
  if (Array.isArray(value)) return value.map(migrateLegacyKeys);
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.entries(value).map(([key, nested]) => [camelCaseKey(key), migrateLegacyKeys(nested)]));
}

export class DataStore {
  constructor(filePath, startingNumber) {
    this.filePath = resolve(filePath);
    this.startingNumber = startingNumber;
    this.data = defaultData(startingNumber);
    this.writeQueue = Promise.resolve();
  }

  async init() {
    try {
      const raw = await readFile(this.filePath, 'utf8');
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
        const legacy = !parsed.schemaVersion;
        const normalized = legacy ? migrateLegacyKeys(parsed) : parsed;
        this.data = {
          ...defaultData(this.startingNumber),
          ...normalized,
          schemaVersion: 2,
          tickets: normalized.tickets && typeof normalized.tickets === 'object' ? normalized.tickets : {},
          stats: normalized.stats && typeof normalized.stats === 'object' ? normalized.stats : {},
          privacy: normalized.privacy && typeof normalized.privacy === 'object' ? normalized.privacy : {},
          claimedDepositTxids: normalized.claimedDepositTxids && typeof normalized.claimedDepositTxids === 'object' ? normalized.claimedDepositTxids : {},
          audit: Array.isArray(normalized.audit) ? normalized.audit : []
        };
        if (legacy) {
          this.addAudit('legacy_python_data_migrated', { sourceSchema: 1, targetSchema: 2 });
          await this.save();
        }
      }
    } catch (error) {
      if (error.code !== 'ENOENT') console.error(`Could not load ${this.filePath}:`, error.message);
    }
    return this.data;
  }

  get snapshot() {
    return this.data;
  }

  getTicket(channelId) {
    return this.data.tickets[String(channelId)] ?? null;
  }

  getTicketByNumber(number) {
    return Object.values(this.data.tickets).find((ticket) => Number(ticket.number) === Number(number)) ?? null;
  }

  setTicket(ticket) {
    this.data.tickets[String(ticket.channelId)] = ticket;
  }

  deleteTicket(channelId) {
    delete this.data.tickets[String(channelId)];
  }

  async reserveTicketNumber() {
    const current = Math.max(Number(this.data.nextTicketNumber) || this.startingNumber, this.startingNumber);
    this.data.nextTicketNumber = current + 1;
    await this.save();
    return current;
  }

  async claimDepositTxid(txid, ticketNumber) {
    if (!txid) return true;
    const key = String(txid).trim().toLowerCase();
    if (key.startsWith('manual-')) return true;
    const existing = this.data.claimedDepositTxids[key];
    if (existing !== undefined && Number(existing) !== Number(ticketNumber)) return false;
    this.data.claimedDepositTxids[key] = Number(ticketNumber);
    await this.save();
    return true;
  }

  addAudit(event, details = {}) {
    this.data.audit.push({ at: new Date().toISOString(), event, ...details });
    if (this.data.audit.length > 1000) this.data.audit.splice(0, this.data.audit.length - 1000);
  }

  async save() {
    const payload = `${JSON.stringify(this.data, null, 2)}\n`;
    this.writeQueue = this.writeQueue.then(async () => {
      await mkdir(dirname(this.filePath), { recursive: true });
      const temporary = `${this.filePath}.tmp`;
      await writeFile(temporary, payload, 'utf8');
      await rename(temporary, this.filePath);
    });
    return this.writeQueue;
  }
}
