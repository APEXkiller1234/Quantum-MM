import http from 'node:http';
import { config } from '../config.js';

export function startHealthServer({ store, client, monitor }) {
  const server = http.createServer((request, response) => {
    if (request.url !== '/health' && request.url !== '/') {
      response.writeHead(404, { 'content-type': 'application/json' });
      response.end(JSON.stringify({ ok: false, error: 'not_found' }));
      return;
    }
    const body = {
      ok: true,
      service: 'quantum-mm',
      uptimeSeconds: Math.floor(process.uptime()),
      discordReady: client.isReady(),
      guilds: client.guilds.cache.size,
      activeTickets: Object.keys(store.snapshot.tickets).length,
      activeMonitors: monitor.tasks.size,
      timestamp: new Date().toISOString()
    };
    response.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' });
    response.end(JSON.stringify(body));
  });
  server.listen(config.healthPort, '0.0.0.0', () => console.log(`Health server listening on 0.0.0.0:${config.healthPort}`));
  return server;
}
