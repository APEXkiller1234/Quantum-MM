import { config } from '../config.js';
import { action, logger } from '../logger.js';
import { demoCompletedPayload } from '../ui/components.js';
import { sleep } from '../utils/format.js';

export class DemoService {
  constructor({ client, blockchain }) {
    this.client = client;
    this.blockchain = blockchain;
    this.stopped = false;
  }

  start() {
    if (!config.demo.enabled || this.loopRunning) return;
    this.loopRunning = true;
    this.stopped = false;
    this.loop().catch((error) => logger.error('Demo activity loop stopped', { error: error.message }));
  }

  stop() { this.stopped = true; }

  async loop() {
    while (!this.stopped && config.demo.enabled) {
      const jitter = config.demo.jitterMinSeconds + Math.floor(Math.random() * (config.demo.jitterMaxSeconds - config.demo.jitterMinSeconds + 1));
      await sleep((config.demo.baseIntervalSeconds + jitter) * 1000);
      if (this.stopped) return;
      try {
        const channel = await this.client.channels.fetch(String(config.channels.demoCompleted));
        const sample = await this.blockchain.randomConfirmedLtcSample();
        if (!sample || !channel?.isTextBased()) continue;
        const price = await this.blockchain.getLtcPrice();
        await channel.send(demoCompletedPayload(sample, price));
        action('demo_activity_sent', { channelId: channel.id, txid: sample.txid, blockHeight: sample.blockHeight });
      } catch (error) {
        logger.warn('Demo activity skipped', { error: error.message });
      }
    }
  }
}
