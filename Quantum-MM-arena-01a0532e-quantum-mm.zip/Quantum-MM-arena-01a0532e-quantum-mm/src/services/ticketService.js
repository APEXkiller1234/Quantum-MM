import crypto from 'node:crypto';
import Decimal from 'decimal.js';
import { AttachmentBuilder, ChannelType, PermissionFlagsBits } from 'discord.js';
import { config } from '../config.js';
import { action, logger, security } from '../logger.js';
import { cleanChannelName, cryptoAmount, isAdmin, normalizeTxid, parsePositiveDecimal, requiredCryptoDecimal, sleep, txDisplay, userIsParty } from '../utils/format.js';
import {
  addressConfirmationPayload,
  addressPromptPayload,
  cancellationPayload,
  completedPayload,
  demoCompletedPayload,
  paymentInfoPayload,
  proceedPayload,
  releaseConfirmationPayload,
  roleConfirmationPayload,
  roleSelectionPayload,
  sendingPayload,
  settlementPendingPayload,
  settlementRequestPayload,
  simpleNotice,
  ticketOpenerPayload,
  transactionConfirmedPayload,
  transactionDetectedPayload,
  transcriptLogPayload,
  usdConfirmationPayload,
  usdPromptPayload,
  withdrawalSuccessPayload,
  setPrivacyLookup
} from '../ui/components.js';

const FUNDED_STATUSES = new Set([
  'depositUnconfirmed', 'depositConfirmed', 'trade', 'cancellation',
  'releaseConfirmation', 'addressPrompt', 'addressConfirmation',
  'settlementPending', 'cancelledPendingSettlement', 'completed'
]);

const ACTIVE_DEPOSIT_STATUSES = new Set(['waitingDeposit', 'depositUnconfirmed']);

function ticketId(ticket) {
  return { ticket: ticket.number, channelId: ticket.channelId };
}

export class TicketService {
  constructor({ client, store, blockchain }) {
    this.client = client;
    this.store = store;
    this.blockchain = blockchain;
    this.startMonitor = null;
    this.stopMonitor = null;
    this.startCountdown = null;
    this.cancelCountdown = null;
    setPrivacyLookup((userId) => this.store.snapshot.privacy[String(userId)] ?? true);
  }

  setMonitorHooks({ start, stop }) {
    this.startMonitor = start;
    this.stopMonitor = stop;
  }

  setCountdownHooks({ start, cancel }) {
    this.startCountdown = start;
    this.cancelCountdown = cancel;
  }

  get(channelId) { return this.store.getTicket(channelId); }
  getByNumber(number) { return this.store.getTicketByNumber(number); }

  async getChannel(guildId, channelId) {
    const guild = this.client.guilds.cache.get(String(guildId));
    let channel = guild?.channels.cache.get(String(channelId));
    if (!channel) {
      try { channel = await this.client.channels.fetch(String(channelId)); } catch { return null; }
    }
    return channel;
  }

  async resolveTrader(guild, rawValue) {
    const value = String(rawValue ?? '').trim();
    const mentionMatch = value.match(/^<@!?(\d+)>$/);
    const id = mentionMatch?.[1] ?? (value.match(/^\d+$/)?.[0]);
    if (id) {
      const cached = guild.members.cache.get(id);
      if (cached) return cached;
      try { return await guild.members.fetch(id); } catch { return null; }
    }
    const lowered = value.toLowerCase().replace(/^@/, '');
    return guild.members.cache.find((member) => [member.user.username, member.displayName, member.user.tag].some((candidate) => candidate.toLowerCase() === lowered)) ?? null;
  }

  async createTicket({ guild, opener, trader, type, openerSide, traderSide }) {
    const category = guild.channels.cache.get(String(config.channels.ticketCategory));
    if (!category || category.type !== ChannelType.GuildCategory) throw new Error('The configured ticket category could not be found.');
    if (type !== 'ltc' && type !== 'usdt') throw new Error('Unsupported asset.');

    const number = await this.store.reserveTicketNumber();
    const botMember = guild.members.me;
    const deniedForUsers = [PermissionFlagsBits.SendMessages, PermissionFlagsBits.AddReactions, PermissionFlagsBits.AttachFiles, PermissionFlagsBits.EmbedLinks, PermissionFlagsBits.CreatePublicThreads, PermissionFlagsBits.CreatePrivateThreads, PermissionFlagsBits.SendMessagesInThreads];
    const permissionOverwrites = [
      { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
      { id: opener.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory], deny: deniedForUsers },
      { id: trader.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory], deny: deniedForUsers }
    ];
    if (botMember) permissionOverwrites.push({ id: botMember.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ManageMessages, PermissionFlagsBits.AttachFiles, PermissionFlagsBits.EmbedLinks] });

    const channel = await guild.channels.create({
      name: `${type}-${cleanChannelName(opener.displayName)}-${number}`,
      type: ChannelType.GuildText,
      parent: category.id,
      topic: `quantum-mm|number=${number}|opener=${opener.id}|trader=${trader.id}|type=${type}`,
      permissionOverwrites,
      reason: `Quantum-MM middleman ticket ${number}`
    });

    const ticket = {
      number,
      guildId: guild.id,
      channelId: channel.id,
      type,
      openerId: opener.id,
      traderId: trader.id,
      openerSide,
      traderSide,
      senderId: null,
      receiverId: null,
      roleConfirmed: [],
      usdAmount: null,
      usdConfirmed: [],
      cryptoPrice: null,
      cryptoAmount: null,
      depositAddress: null,
      depositTxid: null,
      depositAmount: null,
      depositConfirmations: 0,
      baselineTxids: [],
      manualDepositOverride: false,
      manualReference: null,
      receiverAddress: null,
      releaseAuthorized: false,
      releaseConfirmReady: false,
      releaseCountdownEnd: 0,
      addressConfirmReady: false,
      addressCountdownEnd: 0,
      payoutTxid: null,
      payoutAmount: null,
      payoutIsSimulation: false,
      uncancelVotes: [],
      cancelVotes: [],
      status: 'created',
      createdAt: Date.now(),
      completedAt: null,
      statsRecorded: false,
      completedLogged: false,
      withdrawalSuccessSent: false,
      completedChannelSent: false,
      messages: {}
    };
    this.store.setTicket(ticket);
    this.store.addAudit('ticket_created', ticketId(ticket));
    await this.store.save();

    const openerMessage = await channel.send(ticketOpenerPayload(opener, trader, ticket));
    ticket.messages.opener = openerMessage.id;
    await this.store.save();
    await this.sendRoleSelection(channel, ticket);
    action('ticket_created', { ...ticketId(ticket), type, opener: opener.id, trader: trader.id });
    return { channel, ticket };
  }

  async sendRoleSelection(channel, ticket) {
    ticket.status = 'roleSelection';
    ticket.senderId = null;
    ticket.receiverId = null;
    ticket.roleConfirmed = [];
    await this.store.save();
    const message = await channel.send(roleSelectionPayload(ticket));
    ticket.messages.roleSelection = message.id;
    await this.store.save();
  }

  async sendRoleConfirmation(channel, ticket) {
    ticket.status = 'roleConfirmation';
    ticket.roleConfirmed = [];
    await this.store.save();
    const message = await channel.send(roleConfirmationPayload(ticket));
    ticket.messages.roleConfirmation = message.id;
    await this.store.save();
  }

  async sendUsdPrompt(channel, ticket) {
    ticket.status = 'usdPrompt';
    await this.store.save();
    const message = await channel.send(usdPromptPayload());
    ticket.messages.usdPrompt = message.id;
    await this.store.save();
  }

  async sendUsdConfirmation(channel, ticket) {
    ticket.status = 'usdConfirmation';
    ticket.usdConfirmed = [];
    await this.store.save();
    const message = await channel.send(usdConfirmationPayload(ticket));
    ticket.messages.usdConfirmation = message.id;
    await this.store.save();
  }

  async buildBaseline(ticket) {
    if (ticket.type === 'ltc') {
      if (!config.autoMonitorLtc) return [];
      const txs = await this.blockchain.fetchLtcTransactions(ticket.depositAddress);
      if (!txs) return null;
      return txs.map((tx) => normalizeTxid(tx.hash)).filter(Boolean);
    }
    if (!config.autoMonitorUsdt) return [];
    const transfers = await this.blockchain.fetchUsdtTransfers(ticket.depositAddress);
    if (!transfers) return null;
    return transfers.map((transfer) => normalizeTxid(transfer.hash)).filter(Boolean);
  }

  async sendPaymentInfo(channel, ticket) {
    let price;
    let amount;
    if (ticket.type === 'ltc') {
      price = await this.blockchain.getLtcPrice();
      if (!price) {
        ticket.status = 'usdConfirmation';
        ticket.usdConfirmed = [];
        await this.store.save();
        await channel.send(simpleNotice('❌ · **Unable to retrieve the current LTC price. Please confirm the USD amount again.**', 0xdb504c));
        await this.sendUsdConfirmation(channel, ticket);
        return false;
      }
      amount = new Decimal(ticket.usdAmount).dividedBy(price).toDecimalPlaces(5, Decimal.ROUND_DOWN);
    } else {
      price = new Decimal(1);
      amount = new Decimal(ticket.usdAmount).toDecimalPlaces(2);
    }

    ticket.cryptoPrice = price.toString();
    ticket.cryptoAmount = amount.toString();
    ticket.depositAddress = ticket.type === 'ltc' ? config.wallets.ltc : config.wallets.usdt;
    ticket.depositTxid = null;
    ticket.depositAmount = null;
    ticket.depositConfirmations = 0;
    ticket.manualDepositOverride = false;
    ticket.manualReference = null;
    const baseline = await this.buildBaseline(ticket);
    if (!baseline) {
      ticket.status = 'usdConfirmation';
      ticket.usdConfirmed = [];
      await this.store.save();
      await channel.send(simpleNotice('❌ · **Unable to initialize blockchain monitoring. Please confirm the USD amount again.**', 0xdb504c));
      await this.sendUsdConfirmation(channel, ticket);
      return false;
    }

    ticket.baselineTxids = baseline;
    ticket.status = 'waitingDeposit';
    ticket.paymentStartedAt = Date.now();
    await this.store.save();
    const message = await channel.send(paymentInfoPayload(ticket));
    ticket.messages.paymentInfo = message.id;
    await this.store.save();
    action('payment_details_ready', { ...ticketId(ticket), asset: ticket.type, usd: ticket.usdAmount, crypto: ticket.cryptoAmount });
    this.startMonitor?.(ticket);
    return true;
  }

  async handleDepositDetected(ticket, txid, amount, confirmations) {
    if (txid && !(await this.store.claimDepositTxid(txid, ticket.number))) {
      security('deposit_txid_rejected_already_claimed', { ...ticketId(ticket), txid });
      return;
    }
    const current = this.get(ticket.channelId);
    if (!current || !ACTIVE_DEPOSIT_STATUSES.has(current.status)) return;
    const previous = current.depositTxid;
    const replacingManual = Boolean(current.manualDepositOverride && txid && current.manualReference);
    if (txid) current.depositTxid = txid;
    current.depositAmount = new Decimal(amount).toString();
    current.depositConfirmations = Number(confirmations) || 0;
    current.status = 'depositUnconfirmed';
    if (replacingManual) current.manualDepositOverride = false;
    const changed = Boolean(txid && (!previous || normalizeTxid(previous) !== normalizeTxid(txid)));
    await this.store.save();

    const channel = await this.getChannel(current.guildId, current.channelId);
    if (!channel) return;
    let message = current.messages.depositDetected ? await channel.messages.fetch(current.messages.depositDetected).catch(() => null) : null;
    if ((changed || replacingManual) && message) await message.edit(transactionDetectedPayload(current)).catch(() => { message = null; });
    if (changed && !message) {
      message = await channel.send(transactionDetectedPayload(current));
      current.messages.depositDetected = message.id;
      await this.store.save();
    }
    action('deposit_detected', { ...ticketId(current), amount: String(amount), confirmations: current.depositConfirmations, txid: txid || 'none' });
    const required = requiredCryptoDecimal(current);
    if (new Decimal(amount).gte(required) && current.depositConfirmations >= (current.type === 'ltc' ? config.ltcConfirmations : config.usdtConfirmations)) await this.handleDepositConfirmed(current);
  }

  async handleDepositConfirmed(ticket) {
    const current = this.get(ticket.channelId);
    if (!current || ['depositConfirmed', 'trade', 'cancellation', 'releaseConfirmation', 'addressPrompt', 'addressConfirmation', 'settlementPending', 'completed'].includes(current.status)) return;
    if (!current.depositAmount || new Decimal(current.depositAmount).lt(requiredCryptoDecimal(current))) return;
    const requiredConfirmations = current.type === 'ltc' ? config.ltcConfirmations : config.usdtConfirmations;
    if (Number(current.depositConfirmations) < requiredConfirmations) return;
    current.status = 'depositConfirmed';
    await this.store.save();
    const channel = await this.getChannel(current.guildId, current.channelId);
    if (!channel) return;
    const confirmed = await channel.send(transactionConfirmedPayload(current));
    current.messages.depositConfirmed = confirmed.id;
    const proceed = await channel.send(proceedPayload(current));
    current.messages.proceed = proceed.id;
    current.status = 'trade';
    await this.store.save();
    action('deposit_confirmed', { ...ticketId(current), amount: current.depositAmount, confirmations: current.depositConfirmations, txid: current.depositTxid });
  }

  async sendReleaseConfirmation(channel, ticket) {
    ticket.status = 'releaseConfirmation';
    ticket.releaseConfirmReady = false;
    ticket.releaseCountdownEnd = Date.now() + 3000;
    await this.store.save();
    const message = await channel.send(releaseConfirmationPayload(ticket, 3));
    ticket.messages.releaseConfirmation = message.id;
    await this.store.save();
    this.startCountdown?.(ticket, 'release', message.id, true);
  }

  async sendAddressPrompt(channel, ticket) {
    ticket.status = 'addressPrompt';
    await this.store.save();
    const message = await channel.send(addressPromptPayload(ticket));
    ticket.messages.addressPrompt = message.id;
    await this.store.save();
  }

  async sendAddressConfirmation(channel, ticket) {
    ticket.status = 'addressConfirmation';
    ticket.addressConfirmReady = false;
    ticket.addressCountdownEnd = Date.now() + 3000;
    await this.store.save();
    const message = await channel.send(addressConfirmationPayload(ticket, 3));
    ticket.messages.addressConfirmation = message.id;
    await this.store.save();
    this.startCountdown?.(ticket, 'address', message.id, true);
  }

  async sendSettlementRequest(ticket) {
    const channel = await this.getChannel(ticket.guildId, config.channels.settlement);
    if (!channel?.isTextBased()) return false;
    await channel.send(settlementRequestPayload(ticket));
    action('settlement_request_sent', { ...ticketId(ticket), asset: ticket.type, receiver: ticket.receiverId });
    return true;
  }

  async resumeCompletedOutputs() {
    for (const ticket of Object.values(this.store.snapshot.tickets)) {
      if (ticket.status !== 'completed') continue;
      try {
        await this.sendCompletionOutputs(ticket);
      } catch (error) {
        logger.error('Failed to resume completed-ticket outputs', { ticket: ticket.number, error: error.message });
      }
    }
  }

  async finalizeWithdrawal(ticket, payoutTxid, payoutAmount, simulation = false) {
    const current = this.get(ticket.channelId);
    if (!current || current.status !== 'settlementPending') return false;
    current.payoutTxid = String(payoutTxid);
    current.payoutAmount = new Decimal(payoutAmount).toString();
    current.payoutIsSimulation = Boolean(simulation);
    current.status = 'completed';
    current.completedAt = Date.now();

    if (!current.statsRecorded) {
      for (const userId of new Set([current.senderId, current.receiverId].filter(Boolean).map(String))) {
        const stats = this.store.snapshot.stats[userId] ?? { dealsCompleted: 0, totalUsdValue: '0.00' };
        stats.dealsCompleted = Number(stats.dealsCompleted || 0) + 1;
        stats.totalUsdValue = new Decimal(stats.totalUsdValue || 0).plus(current.usdAmount || 0).toDecimalPlaces(2).toFixed(2);
        this.store.snapshot.stats[userId] = stats;
      }
      current.statsRecorded = true;
    }
    current.completedLogged = true;
    this.store.addAudit('withdrawal_finalized', { ...ticketId(current), simulation });
    await this.store.save();
    await this.sendCompletionOutputs(current);
    action('withdrawal_finalized', { ...ticketId(current), asset: current.type, amount: current.payoutAmount, txid: current.payoutTxid, simulation });
    return true;
  }

  async sendCompletionOutputs(ticket) {
    const ticketChannel = await this.getChannel(ticket.guildId, ticket.channelId);
    if (ticketChannel?.isTextBased() && !ticket.withdrawalSuccessSent) {
      const message = await ticketChannel.send(withdrawalSuccessPayload(ticket)).catch((error) => { logger.error('Failed to send withdrawal success', { ticket: ticket.number, error: error.message }); return null; });
      if (message) {
        ticket.messages.withdrawalSuccess = message.id;
        ticket.withdrawalSuccessSent = true;
        await this.store.save();
      }
    }
    if (!ticket.completedChannelSent) {
      const completedChannel = await this.getChannel(ticket.guildId, config.channels.completed);
      if (completedChannel?.isTextBased()) {
        try {
          await completedChannel.send(completedPayload(ticket));
          ticket.completedChannelSent = true;
          await this.store.save();
        } catch (error) {
          logger.error('Failed to send completed trade log', { ticket: ticket.number, error: error.message });
        }
      }
    }
  }

  async buildTranscript(channel) {
    const messages = [];
    let before;
    while (true) {
      const page = await channel.messages.fetch({ limit: 100, ...(before ? { before } : {}) });
      if (!page.size) break;
      messages.push(...page.values());
      if (page.size < 100) break;
      before = page.last().id;
    }
    messages.sort((a, b) => a.createdTimestamp - b.createdTimestamp);
    const lines = [];
    for (const message of messages) {
      lines.push(`[${message.createdAt.toISOString()}] ${message.author.tag} (${message.author.id})`);
      if (message.reference?.messageId) lines.push(`REPLY: ${message.reference.messageId}`);
      if (message.content) lines.push(message.content);
      message.embeds.forEach((embed, index) => {
        lines.push(`EMBED ${index + 1}`);
        if (embed.title) lines.push(`TITLE: ${embed.title}`);
        if (embed.description) lines.push(`DESCRIPTION: ${embed.description}`);
        if (embed.color) lines.push(`COLOR: ${embed.color}`);
        for (const field of embed.fields) lines.push(`FIELD ${field.name}: ${field.value}`);
        if (embed.footer?.text) lines.push(`FOOTER: ${embed.footer.text}`);
      });
      for (const attachment of message.attachments.values()) lines.push(`ATTACHMENT: ${attachment.name} ${attachment.url}`);
      lines.push('');
    }
    return lines.join('\n');
  }

  async closeTicket(channel, ticket, reason) {
    const transcriptChannel = await this.getChannel(ticket.guildId, config.channels.transcripts);
    if (!transcriptChannel?.isTextBased()) {
      await channel.send(simpleNotice('❌ · **The transcript channel could not be found. The ticket was not deleted.**', 0xdb504c)).catch(() => {});
      return false;
    }
    action('ticket_close_started', { ...ticketId(ticket), reason });
    let transcript;
    try { transcript = await this.buildTranscript(channel); } catch (error) {
      logger.error('Failed to build transcript', { ticket: ticket.number, error: error.message });
      await channel.send(simpleNotice('❌ · **The transcript could not be saved. The ticket was not deleted.**', 0xdb504c)).catch(() => {});
      return false;
    }
    try {
      await transcriptChannel.send({ ...transcriptLogPayload(ticket, reason), allowedMentions: { parse: [] } });
      await transcriptChannel.send({ files: [new AttachmentBuilder(Buffer.from(transcript, 'utf8'), { name: `ticket-${ticket.number}-transcript.txt` })] });
    } catch (error) {
      logger.error('Failed to log transcript', { ticket: ticket.number, error: error.message });
      await channel.send(simpleNotice('❌ · **The transcript could not be saved. The ticket was not deleted.**', 0xdb504c)).catch(() => {});
      return false;
    }

    const deleted = await channel.delete({ reason }).then(() => true).catch((error) => {
      logger.error('Failed to delete ticket channel', { channelId: ticket.channelId, error: error.message });
      return false;
    });
    if (!deleted) return false;
    this.stopMonitor?.(ticket.channelId);
    this.cancelCountdown?.(ticket.channelId, 'release');
    this.cancelCountdown?.(ticket.channelId, 'address');
    this.store.deleteTicket(ticket.channelId);
    await this.store.save();
    action('ticket_closed', ticketId(ticket));
    return true;
  }

  async markDeposit(ticketNumber, amountText, confirmations) {
    const existing = this.getByNumber(ticketNumber);
    if (!existing) throw new Error('Ticket not found.');
    const ticket = this.get(existing.channelId);
    if (!ticket || !ACTIVE_DEPOSIT_STATUSES.has(ticket.status)) throw new Error('The ticket is not waiting for a deposit.');
    const amount = parsePositiveDecimal(amountText);
    if (!amount) throw new Error('Enter a valid positive deposit amount.');
    const expected = requiredCryptoDecimal(ticket);
    if (ticket.type === 'ltc' && !amount.eq(expected)) throw new Error(`The LTC amount must exactly match ${cryptoAmount(ticket, expected)} LTC.`);
    if (!ticket.manualReference) ticket.manualReference = `MANUAL-${crypto.randomBytes(32).toString('hex').toUpperCase()}`;
    ticket.depositTxid = ticket.manualReference;
    ticket.depositAmount = (ticket.type === 'ltc' ? expected : amount).toString();
    ticket.depositConfirmations = Number(confirmations);
    ticket.manualDepositOverride = true;
    ticket.status = 'depositUnconfirmed';
    await this.store.save();
    const channel = await this.getChannel(ticket.guildId, ticket.channelId);
    if (!channel) throw new Error('The ticket channel could not be found.');
    let message = ticket.messages.depositDetected ? await channel.messages.fetch(ticket.messages.depositDetected).catch(() => null) : null;
    if (message) await message.edit(transactionDetectedPayload(ticket)).catch(() => { message = null; });
    if (!message) {
      message = await channel.send(transactionDetectedPayload(ticket));
      ticket.messages.depositDetected = message.id;
      await this.store.save();
    }
    if (amount.gte(expected) && Number(confirmations) >= (ticket.type === 'ltc' ? config.ltcConfirmations : config.usdtConfirmations)) await this.handleDepositConfirmed(ticket);
    else this.startMonitor?.(ticket);
    return ticket;
  }

  async settleTicket(ticket, payoutTxid, payoutAmount) {
    if (ticket.status !== 'settlementPending') throw new Error('That ticket is no longer waiting for settlement.');
    const amount = parsePositiveDecimal(payoutAmount);
    if (!amount) throw new Error('Enter a valid positive payout amount.');
    if (!ticket.receiverAddress) throw new Error('The receiver has not confirmed a payout address.');
    if (!ticket.depositAmount || amount.lt(ticket.depositAmount)) throw new Error(`The payout cannot be below the escrowed amount of ${cryptoAmount(ticket, ticket.depositAmount)} ${ticket.type.toUpperCase()}.`);
    const verification = await this.blockchain.verifyPayout(ticket, payoutTxid.trim(), amount);
    if (!verification.verified) throw new Error(`Settlement verification failed: ${verification.error}\nConfirmations detected: ${verification.confirmations}`);
    const finalized = await this.finalizeWithdrawal(ticket, payoutTxid.trim(), verification.actualAmount, false);
    if (!finalized) throw new Error('That ticket was finalized by another settlement attempt.');
    return verification;
  }

  ticketInfo(ticket) {
    return {
      number: ticket.number,
      status: ticket.status,
      asset: ticket.type.toUpperCase(),
      senderId: ticket.senderId,
      receiverId: ticket.receiverId,
      usdAmount: ticket.usdAmount,
      depositAmount: ticket.depositAmount,
      depositTxid: ticket.depositTxid,
      receiverAddress: ticket.receiverAddress,
      payoutAmount: ticket.payoutAmount,
      payoutTxid: ticket.payoutTxid,
      createdAt: ticket.createdAt,
      completedAt: ticket.completedAt
    };
  }
}

export { FUNDED_STATUSES, ACTIVE_DEPOSIT_STATUSES };
