import Decimal from 'decimal.js';
import { config } from '../config.js';
import { logger, action } from '../logger.js';
import { normalizeTxid, requiredCryptoDecimal, sleep } from '../utils/format.js';

export class MonitorService {
  constructor({ store, blockchain, tickets }) {
    this.store = store;
    this.blockchain = blockchain;
    this.tickets = tickets;
    this.tasks = new Map();
  }

  start(ticket) {
    const key = String(ticket.channelId);
    const existing = this.tasks.get(key);
    if (existing && !existing.stopped) return;
    const task = { stopped: false };
    this.tasks.set(key, task);
    this.loop(Number(ticket.channelId), task).catch((error) => logger.error('Deposit monitor stopped unexpectedly', { channelId: ticket.channelId, error: error.message }));
  }

  stop(channelId) {
    const task = this.tasks.get(String(channelId));
    if (task) task.stopped = true;
    this.tasks.delete(String(channelId));
  }

  async resume() {
    for (const ticket of Object.values(this.store.snapshot.tickets)) {
      if (['waitingDeposit', 'depositUnconfirmed'].includes(ticket.status)) this.start(ticket);
    }
  }

  async loop(channelId, task) {
    try {
      while (!task.stopped) {
        const ticket = this.store.getTicket(channelId);
        if (!ticket || !['waitingDeposit', 'depositUnconfirmed'].includes(ticket.status)) return;
        try {
          if (ticket.type === 'ltc' && config.autoMonitorLtc) await this.monitorLtc(ticket);
          if (ticket.type === 'usdt' && config.autoMonitorUsdt) await this.monitorUsdt(ticket);
        } catch (error) {
          logger.error('Deposit monitor iteration failed', { channelId, error: error.message });
        }

        const current = this.store.getTicket(channelId);
        if (!current) return;
        if (config.autoCloseUnpaid && current.status === 'waitingDeposit' && Date.now() - Number(current.paymentStartedAt || Date.now()) >= config.unpaidTimeoutSeconds * 1000) {
          const channel = await this.tickets.getChannel(current.guildId, current.channelId);
          if (channel?.isTextBased()) {
            await channel.send({ embeds: [{ description: '❌ · **No transaction was detected. Closing ticket...**', color: 0xdb504c }] }).catch(() => {});
            await sleep(3000);
            await this.tickets.closeTicket(channel, current, 'Unpaid ticket timeout');
          }
          return;
        }
        await sleep(config.monitorIntervalSeconds * 1000);
      }
    } finally {
      if (this.tasks.get(String(channelId)) === task) this.tasks.delete(String(channelId));
      action('deposit_monitor_stopped', { channelId });
    }
  }

  async monitorLtc(ticket) {
    const txs = await this.blockchain.fetchLtcTransactions(ticket.depositAddress);
    if (!txs) return;
    const expectedSatoshi = new Decimal(requiredCryptoDecimal(ticket)).times(100000000).toDecimalPlaces(0, Decimal.ROUND_DOWN).toNumber();
    let currentTxid = ticket.depositTxid;
    if (ticket.manualDepositOverride) currentTxid = null;

    if (currentTxid) {
      const tx = txs.find((candidate) => normalizeTxid(candidate.hash) === normalizeTxid(currentTxid));
      if (!tx) return;
      const received = this.blockchain.ltcReceivedByTx(tx, ticket.depositAddress);
      if (received < expectedSatoshi) return;
      await this.tickets.handleDepositDetected(ticket, tx.hash, new Decimal(received).dividedBy(100000000), Number(tx.confirmations) || 0);
      return;
    }

    const baseline = new Set(ticket.baselineTxids ?? []);
    for (const tx of txs) {
      const txid = tx.hash;
      const normalized = normalizeTxid(txid);
      if (!txid || baseline.has(normalized)) continue;
      const claimedBy = this.store.snapshot.claimedDepositTxids[normalized];
      if (claimedBy !== undefined && Number(claimedBy) !== Number(ticket.number)) continue;
      const received = this.blockchain.ltcReceivedByTx(tx, ticket.depositAddress);
      if (received !== expectedSatoshi) continue;
      await this.tickets.handleDepositDetected(ticket, txid, new Decimal(received).dividedBy(100000000), Number(tx.confirmations) || 0);
      return;
    }
  }

  async monitorUsdt(ticket) {
    const transfers = await this.blockchain.fetchUsdtTransfers(ticket.depositAddress);
    if (!transfers) return;
    const expected = requiredCryptoDecimal(ticket);
    let currentTxid = ticket.depositTxid;
    if (ticket.manualDepositOverride) currentTxid = null;

    if (currentTxid) {
      let total = new Decimal(0);
      let confirmations = 0;
      let found = false;
      for (const transfer of transfers) {
        if (normalizeTxid(transfer.hash) !== normalizeTxid(currentTxid) || !this.blockchain.validUsdtTransfer(transfer, ticket.depositAddress)) continue;
        const parsed = this.blockchain.parseUsdtTransfer(transfer);
        total = total.plus(parsed.amount);
        confirmations = Math.max(confirmations, parsed.confirmations);
        found = true;
      }
      if (found && total.gte(expected)) await this.tickets.handleDepositDetected(ticket, currentTxid, total, confirmations);
      return;
    }

    const baseline = new Set(ticket.baselineTxids ?? []);
    const grouped = new Map();
    for (const transfer of transfers) {
      const txid = transfer.hash;
      const normalized = normalizeTxid(txid);
      if (!txid || baseline.has(normalized)) continue;
      const claimedBy = this.store.snapshot.claimedDepositTxids[normalized];
      if (claimedBy !== undefined && Number(claimedBy) !== Number(ticket.number)) continue;
      if (!this.blockchain.validUsdtTransfer(transfer, ticket.depositAddress)) continue;
      const parsed = this.blockchain.parseUsdtTransfer(transfer);
      const item = grouped.get(normalized) ?? { txid, amount: new Decimal(0), confirmations: 0 };
      item.amount = item.amount.plus(parsed.amount);
      item.confirmations = Math.max(item.confirmations, parsed.confirmations);
      grouped.set(normalized, item);
    }
    for (const item of grouped.values()) {
      if (item.amount.eq(expected)) {
        await this.tickets.handleDepositDetected(ticket, item.txid, item.amount, item.confirmations);
        return;
      }
    }
  }
}
