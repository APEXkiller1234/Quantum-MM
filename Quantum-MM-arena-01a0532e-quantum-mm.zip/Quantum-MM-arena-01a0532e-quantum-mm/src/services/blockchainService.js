import Decimal from 'decimal.js';
import { config, network } from '../config.js';
import { decimal, requiredCryptoDecimal, normalizeTxid } from '../utils/format.js';
import { logger, action } from '../logger.js';

export class BlockchainService {
  constructor() {
    this.inFlight = new Map();
  }

  async getJson(url, { params = {}, timeoutMs = 15000, attempts = 3 } = {}) {
    const query = new URLSearchParams();
    for (const [key, value] of Object.entries(params)) {
      if (value !== undefined && value !== null && value !== '') query.set(key, String(value));
    }
    const requestUrl = query.size ? `${url}?${query}` : url;
    let lastError;

    for (let attempt = 0; attempt < attempts; attempt += 1) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeoutMs);
      try {
        const response = await fetch(requestUrl, {
          signal: controller.signal,
          headers: { Accept: 'application/json', 'User-Agent': 'Quantum-MM/2.0' }
        });
        if (!response.ok) throw new Error(`HTTP ${response.status}: ${(await response.text()).slice(0, 300)}`);
        return await response.json();
      } catch (error) {
        lastError = error;
        if (attempt + 1 < attempts) await new Promise((resolve) => setTimeout(resolve, 1500 * (attempt + 1)));
      } finally {
        clearTimeout(timer);
      }
    }

    logger.warn('Blockchain API request failed', { url, error: lastError?.message });
    return null;
  }

  async getLtcPrice() {
    const data = await this.getJson(config.providers.ltcPriceUrl, { timeoutMs: 10000 });
    const price = decimal(data?.data?.amount, null);
    if (!price || price.lte(0) || String(data?.data?.currency ?? 'USD').toUpperCase() !== 'USD') {
      logger.warn('Invalid LTC price response');
      return null;
    }
    action('ltc_price_fetched', { provider: 'coinbase', pair: 'LTC-USD', price: price.toString() });
    return price;
  }

  async fetchLtcTransactions(address) {
    const params = { limit: 50 };
    if (config.providers.blockCypherToken) params.token = config.providers.blockCypherToken;
    const data = await this.getJson(`${network.ltcApiBase}/addrs/${encodeURIComponent(address)}/full`, { params });
    return Array.isArray(data?.txs) ? data.txs : null;
  }

  async fetchLtcTransaction(txid) {
    const params = config.providers.blockCypherToken ? { token: config.providers.blockCypherToken } : {};
    return this.getJson(`${network.ltcApiBase}/txs/${encodeURIComponent(txid)}`, { params });
  }

  async ltcChainOverview() {
    const params = config.providers.blockCypherToken ? { token: config.providers.blockCypherToken } : {};
    const data = await this.getJson(network.ltcApiBase, { params });
    const height = Number.parseInt(data?.height, 10);
    return Number.isFinite(height) && height > 0 ? data : null;
  }

  async fetchLtcBlock(height) {
    const params = { txstart: 0, limit: 500 };
    if (config.providers.blockCypherToken) params.token = config.providers.blockCypherToken;
    return this.getJson(`${network.ltcApiBase}/blocks/${Number(height)}`, { params });
  }

  async randomConfirmedLtcSample() {
    const overview = await this.ltcChainOverview();
    if (!overview) return null;
    const tip = Number(overview.height);
    const highest = tip - Math.max(config.demo.minConfirmations + 2, 8);
    const lowest = Math.max(1, highest - Math.max(config.demo.recentBlockWindow, 50));
    if (highest <= lowest) return null;

    for (let attempt = 0; attempt < 8; attempt += 1) {
      const height = Math.floor(Math.random() * (highest - lowest + 1)) + lowest;
      const block = await this.fetchLtcBlock(height);
      let txids = Array.isArray(block?.txids) ? block.txids.filter(Boolean).map(String) : [];
      if (txids.length > 1) txids = txids.slice(1);
      txids = txids.sort(() => Math.random() - 0.5).slice(0, 20);

      for (const txid of txids) {
        const tx = await this.fetchLtcTransaction(txid);
        const confirmations = Number.parseInt(tx?.confirmations, 10) || 0;
        const totalSatoshi = Number.parseInt(tx?.total, 10) || 0;
        if (confirmations >= config.demo.minConfirmations && totalSatoshi > 0) {
          return {
            txid,
            confirmations,
            amountLtc: new Decimal(totalSatoshi).dividedBy(100000000),
            blockHeight: height
          };
        }
      }
    }
    return null;
  }

  async fetchUsdtTransfers(address) {
    if (!config.providers.etherscanApiKey) return null;
    const data = await this.getJson(network.etherscanApiBase, {
      params: {
        chainid: network.bscChainId,
        module: 'account',
        action: 'tokentx',
        contractaddress: network.usdtContract,
        address,
        page: 1,
        offset: 1000,
        sort: 'desc',
        apikey: config.providers.etherscanApiKey
      }
    });
    const status = String(data?.status ?? '');
    const message = String(data?.message ?? '').toLowerCase();
    const result = data?.result;
    if (status === '0' && (message.includes('no transactions') || (typeof result === 'string' && result.toLowerCase().includes('no transactions')))) return [];
    if (status !== '1' || !Array.isArray(result)) {
      logger.warn('Etherscan returned an error', { message: data?.message, result: typeof result === 'string' ? result.slice(0, 200) : undefined });
      return null;
    }
    return result;
  }

  validUsdtTransfer(transfer, destination) {
    return String(transfer?.to ?? '').toLowerCase() === String(destination).toLowerCase()
      && String(transfer?.contractAddress ?? '').toLowerCase() === network.usdtContract.toLowerCase();
  }

  parseUsdtTransfer(transfer) {
    try {
      const decimals = Number.parseInt(transfer.tokenDecimal ?? '18', 10);
      const amount = new Decimal(String(transfer.value ?? '0')).dividedBy(new Decimal(10).pow(decimals));
      return { amount, confirmations: Number.parseInt(transfer.confirmations ?? '0', 10) || 0 };
    } catch {
      return { amount: new Decimal(0), confirmations: 0 };
    }
  }

  ltcReceivedByTx(tx, address) {
    return (tx?.outputs ?? []).reduce((total, output) => {
      const addresses = Array.isArray(output.addresses) ? output.addresses : [];
      return addresses.includes(address) ? total + (Number.parseInt(output.value, 10) || 0) : total;
    }, 0);
  }

  async verifyLtcPayout(ticket, txid, requestedAmount) {
    const tx = await this.fetchLtcTransaction(txid);
    if (!tx) return { verified: false, actualAmount: null, confirmations: 0, error: 'The Litecoin transaction could not be retrieved.' };
    const actualAmount = new Decimal(this.ltcReceivedByTx(tx, ticket.receiverAddress)).dividedBy(100000000);
    const confirmations = Number.parseInt(tx.confirmations, 10) || 0;
    if (actualAmount.lt(requestedAmount)) return { verified: false, actualAmount, confirmations, error: 'The transaction does not send the requested amount to the confirmed receiver address.' };
    if (confirmations < config.ltcConfirmations) return { verified: false, actualAmount, confirmations, error: 'The payout transaction does not have enough confirmations yet.' };
    return { verified: true, actualAmount, confirmations, error: '' };
  }

  async verifyUsdtPayout(ticket, txid, requestedAmount) {
    const transfers = await this.fetchUsdtTransfers(ticket.receiverAddress);
    if (!transfers) return { verified: false, actualAmount: null, confirmations: 0, error: 'The BSC token transfer could not be retrieved.' };
    let total = new Decimal(0);
    let confirmations = 0;
    let found = false;
    for (const transfer of transfers) {
      if (normalizeTxid(transfer.hash) !== normalizeTxid(txid) || !this.validUsdtTransfer(transfer, ticket.receiverAddress)) continue;
      const parsed = this.parseUsdtTransfer(transfer);
      total = total.plus(parsed.amount);
      confirmations = Math.max(confirmations, parsed.confirmations);
      found = true;
    }
    if (!found) return { verified: false, actualAmount: null, confirmations: 0, error: 'The transaction does not contain the expected USDT transfer to the confirmed receiver address.' };
    if (total.lt(requestedAmount)) return { verified: false, actualAmount: total, confirmations, error: 'The USDT transaction amount is below the requested payout amount.' };
    if (confirmations < config.usdtConfirmations) return { verified: false, actualAmount: total, confirmations, error: 'The payout transaction does not have enough confirmations yet.' };
    return { verified: true, actualAmount: total, confirmations, error: '' };
  }

  async verifyPayout(ticket, txid, requestedAmount) {
    return ticket.type === 'ltc'
      ? this.verifyLtcPayout(ticket, txid, requestedAmount)
      : this.verifyUsdtPayout(ticket, txid, requestedAmount);
  }
}
