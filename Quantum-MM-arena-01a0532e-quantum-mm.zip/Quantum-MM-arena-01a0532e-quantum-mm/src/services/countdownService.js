import { logger } from '../logger.js';
import { addressConfirmationPayload, releaseConfirmationPayload } from '../ui/components.js';

export class CountdownService {
  constructor({ store, tickets }) {
    this.store = store;
    this.tickets = tickets;
    this.tasks = new Map();
  }

  key(channelId, kind) { return `${channelId}:${kind}`; }

  cancel(channelId, kind) {
    const task = this.tasks.get(this.key(channelId, kind));
    if (task) clearInterval(task);
    this.tasks.delete(this.key(channelId, kind));
  }

  start(ticket, kind, messageId, resume = false) {
    this.cancel(ticket.channelId, kind);
    if (!resume) ticket[`${kind}CountdownEnd`] = Date.now() + 3000;
    const task = setInterval(() => this.refresh(ticket.channelId, kind, messageId).catch((error) => logger.warn('Countdown refresh failed', { error: error.message })), 1000);
    this.tasks.set(this.key(ticket.channelId, kind), task);
    this.refresh(ticket.channelId, kind, messageId).catch(() => {});
  }

  async resume() {
    for (const ticket of Object.values(this.store.snapshot.tickets)) {
      if (ticket.status === 'releaseConfirmation' && ticket.messages.releaseConfirmation) this.start(ticket, 'release', ticket.messages.releaseConfirmation, true);
      if (ticket.status === 'addressConfirmation' && ticket.messages.addressConfirmation) this.start(ticket, 'address', ticket.messages.addressConfirmation, true);
    }
  }

  async refresh(channelId, kind, messageId) {
    const ticket = this.store.getTicket(channelId);
    const expectedStatus = kind === 'release' ? 'releaseConfirmation' : 'addressConfirmation';
    if (!ticket || ticket.status !== expectedStatus) { this.cancel(channelId, kind); return; }
    const end = Number(ticket[`${kind}CountdownEnd`] || 0);
    const remaining = Math.ceil(Math.max(0, end - Date.now()) / 1000);
    const channel = await this.tickets.getChannel(ticket.guildId, ticket.channelId);
    if (!channel?.isTextBased()) { this.cancel(channelId, kind); return; }
    const message = await channel.messages.fetch(messageId).catch(() => null);
    if (!message) { this.cancel(channelId, kind); return; }
    if (remaining <= 0) {
      ticket[`${kind}ConfirmReady`] = true;
      await this.store.save();
      await message.edit({ components: [(kind === 'release' ? releaseConfirmationPayload(ticket) : addressConfirmationPayload(ticket)).components[0]] }).catch(() => {});
      this.cancel(channelId, kind);
      return;
    }
    const shown = Math.min(3, Math.max(1, remaining));
    const payload = kind === 'release' ? releaseConfirmationPayload(ticket, shown) : addressConfirmationPayload(ticket, shown);
    await message.edit({ components: payload.components }).catch(() => {});
  }
}
