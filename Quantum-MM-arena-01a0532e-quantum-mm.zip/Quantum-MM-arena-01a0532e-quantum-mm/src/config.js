import 'dotenv/config';

const TRUE_VALUES = new Set(['1', 'true', 'yes', 'on']);
const FALSE_VALUES = new Set(['0', 'false', 'no', 'off']);

function string(name, fallback = '') {
  return process.env[name]?.trim() || fallback;
}

function integer(name, fallback = 0) {
  const value = Number.parseInt(process.env[name] ?? '', 10);
  return Number.isFinite(value) ? value : fallback;
}

function decimal(name, fallback = 0) {
  const value = Number.parseFloat(process.env[name] ?? '');
  return Number.isFinite(value) ? value : fallback;
}

function boolean(name, fallback) {
  const raw = process.env[name]?.trim().toLowerCase();
  if (TRUE_VALUES.has(raw)) return true;
  if (FALSE_VALUES.has(raw)) return false;
  return fallback;
}

export const config = Object.freeze({
  env: string('NODE_ENV', 'development'),
  discord: Object.freeze({
    token: string('DISCORD_TOKEN'),
    clientId: string('DISCORD_CLIENT_ID'),
    guildId: string('DISCORD_GUILD_ID'),
    ownerUserId: string('BOT_OWNER_ID')
  }),
  channels: Object.freeze({
    tos: integer('TOS_CHANNEL_ID'),
    middlemanTos: integer('MM_TOS_CHANNEL_ID'),
    ticketCategory: integer('TICKET_CATEGORY_ID'),
    transcripts: integer('TRANSCRIPT_CHANNEL_ID'),
    completed: integer('COMPLETED_TRANSACTION_CHANNEL_ID'),
    settlement: integer('SETTLEMENT_CHANNEL_ID'),
    demoCompleted: integer('DEMO_COMPLETED_TRANSACTION_CHANNEL_ID')
  }),
  wallets: Object.freeze({
    ltc: string('LTC_DEPOSIT_ADDRESS'),
    usdt: string('USDT_DEPOSIT_ADDRESS')
  }),
  providers: Object.freeze({
    blockCypherToken: string('BLOCKCYPHER_TOKEN'),
    etherscanApiKey: string('ETHERSCAN_API_KEY'),
    ltcPriceUrl: string('COINBASE_LTC_PRICE_URL', 'https://api.coinbase.com/v2/prices/LTC-USD/spot')
  }),
  settlementMode: string('SETTLEMENT_MODE', 'manual').toLowerCase(),
  autoMonitorLtc: boolean('AUTO_MONITOR_LTC', true),
  autoMonitorUsdt: boolean('AUTO_MONITOR_USDT', true),
  autoCloseUnpaid: boolean('AUTO_CLOSE_UNPAID', true),
  ltcConfirmations: integer('LTC_CONFIRMATIONS_REQUIRED', 1),
  usdtConfirmations: integer('USDT_CONFIRMATIONS_REQUIRED', 1),
  unpaidTimeoutSeconds: integer('UNPAID_TIMEOUT_SECONDS', 1200),
  monitorIntervalSeconds: integer('MONITOR_INTERVAL_SECONDS', 15),
  demo: Object.freeze({
    enabled: boolean('DEMO_ACTIVITY_ENABLED', false),
    baseIntervalSeconds: integer('DEMO_BASE_INTERVAL_SECONDS', 420),
    jitterMinSeconds: integer('DEMO_JITTER_MIN_SECONDS', 60),
    jitterMaxSeconds: integer('DEMO_JITTER_MAX_SECONDS', 180),
    minConfirmations: integer('DEMO_MIN_CONFIRMATIONS', 6),
    recentBlockWindow: integer('DEMO_RECENT_BLOCK_WINDOW', 500)
  }),
  ticket: Object.freeze({
    startingNumber: integer('STARTING_TICKET_NUMBER', 12077)
  }),
  marketing: Object.freeze({
    biggestTradeUsd: decimal('BIGGEST_TRADE_USD', 24468),
    biggestTradeMessageUrl: string('BIGGEST_TRADE_MESSAGE_URL'),
    tutorialUrl: string('TUTORIAL_URL', 'https://www.youtube.com/watch?v=XIkpcT2WNPI')
  }),
  emojis: Object.freeze({
    ltc: string('LTC_EMOJI'),
    usdt: string('USDT_EMOJI'),
    animatedX: string('ANIMATED_X_EMOJI'),
    animatedWave: string('ANIMATED_WAVE_EMOJI'),
    roleShield: string('ROLE_SHIELD_EMOJI'),
    blueLoading: string('BLUE_LOADING_EMOJI'),
    greenTick: string('GREEN_TICK_EMOJI'),
    load: string('LOAD_EMOJI')
  }),
  healthPort: integer('HEALTH_PORT', 3000)
});

function isPositiveId(value) {
  return /^\d{5,25}$/.test(String(value));
}

export function validateConfig({ allowIncomplete = false } = {}) {
  const errors = [];
  const requiredStrings = [
    ['DISCORD_TOKEN', config.discord.token],
    ['DISCORD_CLIENT_ID', config.discord.clientId],
    ['LTC_DEPOSIT_ADDRESS', config.wallets.ltc],
    ['USDT_DEPOSIT_ADDRESS', config.wallets.usdt]
  ];

  for (const [name, value] of requiredStrings) {
    if (!value) errors.push(name);
  }

  const requiredIds = [
    ['BOT_OWNER_ID', config.discord.ownerUserId],
    ['TOS_CHANNEL_ID', config.channels.tos],
    ['MM_TOS_CHANNEL_ID', config.channels.middlemanTos],
    ['TICKET_CATEGORY_ID', config.channels.ticketCategory],
    ['TRANSCRIPT_CHANNEL_ID', config.channels.transcripts],
    ['COMPLETED_TRANSACTION_CHANNEL_ID', config.channels.completed],
    ['SETTLEMENT_CHANNEL_ID', config.channels.settlement]
  ];

  if (config.demo.enabled) requiredIds.push(['DEMO_COMPLETED_TRANSACTION_CHANNEL_ID', config.channels.demoCompleted]);
  for (const [name, value] of requiredIds) {
    if (!isPositiveId(value)) errors.push(name);
  }

  if (config.wallets.usdt && !/^0x[a-fA-F0-9]{40}$/.test(config.wallets.usdt)) errors.push('USDT_DEPOSIT_ADDRESS (BSC address)');
  if (config.autoMonitorUsdt && !config.providers.etherscanApiKey) errors.push('ETHERSCAN_API_KEY');
  if (!['manual', 'simulation'].includes(config.settlementMode)) errors.push('SETTLEMENT_MODE (manual or simulation)');
  if (config.demo.enabled) {
    if (config.channels.demoCompleted === config.channels.completed) errors.push('DEMO_COMPLETED_TRANSACTION_CHANNEL_ID must differ from COMPLETED_TRANSACTION_CHANNEL_ID');
    if (config.demo.baseIntervalSeconds < 60) errors.push('DEMO_BASE_INTERVAL_SECONDS must be at least 60');
    if (config.demo.jitterMinSeconds < 0 || config.demo.jitterMaxSeconds < config.demo.jitterMinSeconds) errors.push('DEMO_JITTER_MIN_SECONDS/DEMO_JITTER_MAX_SECONDS');
    if (config.demo.minConfirmations < 1) errors.push('DEMO_MIN_CONFIRMATIONS');
  }
  if (config.monitorIntervalSeconds < 5) errors.push('MONITOR_INTERVAL_SECONDS must be at least 5');
  if (config.unpaidTimeoutSeconds < 60) errors.push('UNPAID_TIMEOUT_SECONDS must be at least 60');

  if (errors.length && !allowIncomplete) {
    throw new Error(`Configure the following values before starting the bot: ${errors.join(', ')}`);
  }
  return errors;
}

export const network = Object.freeze({
  usdtContract: '0x55d398326f99059ff775485246999027b3197955',
  bscChainId: '56',
  ltcApiBase: 'https://api.blockcypher.com/v1/ltc/main',
  etherscanApiBase: 'https://api.etherscan.io/v2/api'
});
