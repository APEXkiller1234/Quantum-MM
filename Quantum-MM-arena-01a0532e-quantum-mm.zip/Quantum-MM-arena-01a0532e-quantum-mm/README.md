# Quantum-MM

Quantum-MM is a modular Discord cryptocurrency middleman bot rewritten in JavaScript for Node.js. It guides two Discord users through a trade, monitors LTC or USDT BEP-20 deposits, records a private ticket, and lets an administrator verify the external payout before the trade is archived.

> **Important:** this project does not hold private keys or sign blockchain transactions. In `manual` settlement mode, an administrator sends the payout using an external wallet and then gives the bot the transaction ID to verify. Review the code and your operational/security procedures before handling real funds.

## Features

- Private, numbered ticket channels with trader-only permissions
- Role selection and mutual confirmation
- USD amount confirmation by both parties
- LTC pricing from Coinbase
- LTC deposit monitoring through BlockCypher
- USDT BEP-20 transfer monitoring through Etherscan on BSC
- Confirmation checks, exact-amount checks, baseline transaction snapshots, and duplicate transaction protection
- 20-minute unpaid-ticket timeout
- Release and withdrawal-address confirmation countdowns
- Manual settlement verification against public blockchain APIs
- Optional clearly labeled simulation settlement mode
- Completed-trade posts with per-user privacy controls
- User statistics and a leaderboard
- Full message/embed/attachment transcripts
- Persistent state in an atomic local JSON file
- Resume of deposit monitors and countdowns after restart
- JSON health endpoint for hosting platforms
- Graceful shutdown and structured console logs

## Project layout

```text
.
├── .env.example
├── .gitignore
├── package.json
├── README.md
├── scripts/
│   └── check-syntax.mjs
├── tests/
│   └── format.test.js
└── src/
    ├── bot.js
    ├── commands.js
    ├── config.js
    ├── index.js
    ├── logger.js
    ├── handlers/
    │   └── interactionHandler.js
    ├── services/
    │   ├── blockchainService.js
    │   ├── countdownService.js
    │   ├── demoService.js
    │   ├── healthServer.js
    │   ├── monitorService.js
    │   └── ticketService.js
    ├── storage/
    │   └── dataStore.js
    ├── ui/
    │   └── components.js
    └── utils/
        └── format.js
```

## Setup

Requirements:

- Node.js 20 or newer
- A Discord application and bot
- A Discord server where the bot can create/manage channels
- An LTC deposit address
- A BSC address for USDT deposits
- An Etherscan API key when USDT monitoring is enabled

Install dependencies:

```bash
npm install
cp .env.example .env
```

Fill in `.env`. The bot intentionally refuses to start when required values are missing. Never commit `.env`, bot tokens, API keys, private keys, or `middleman_data.json`.

Register the bot with at least these permissions in the target server:

- View Channels
- Send Messages
- Read Message History
- Manage Channels
- Manage Messages
- Embed Links
- Attach Files

The bot should also have the `Server Members Intent` enabled because trader lookup supports usernames and IDs.

Run a syntax check and tests:

```bash
npm run check
npm test
```

Start the bot:

```bash
npm start
```

For development, `npm run dev` uses Node's watch mode.

## Commands

- `/panel` — administrator-only; posts the ticket panel.
- `/stats user:<user>` — displays completed deal count and USD volume.
- `/leaderboard [limit]` — displays the most active traders.
- `/setprivacy private:<true|false>` — controls identity display in completed posts.
- `/ticket-info ticket_number:<number>` — lets ticket parties or administrators inspect a ticket.
- `/mark-deposit ticket_number amount confirmation` — owner-only manual deposit override.
- `/settle ticket_number payout_txid payout_amount` — administrator-only payout verification.
- `/health` — displays bot/monitor status in Discord. The HTTP endpoint is also available at `/health` on `HEALTH_PORT`.

## Trade lifecycle

1. An administrator posts `/panel`.
2. A user selects LTC or USDT and identifies their trader.
3. Quantum-MM creates a private ticket channel.
4. Both parties select and confirm sender/receiver roles.
5. The sender enters the USD amount and both parties confirm it.
6. The bot calculates the required deposit, snapshots existing chain activity, and starts monitoring.
7. The deposit must match the expected amount and confirmation requirement.
8. The sender releases the escrow after the off-platform item/payment exchange.
9. The receiver submits and confirms a payout address.
10. Manual mode posts an administrator settlement request. The administrator sends the payout externally and runs `/settle`.
11. The bot verifies the payout, posts completion output, records statistics, and eventually saves a transcript before deleting the ticket channel.

## Settlement modes

`SETTLEMENT_MODE=manual` is the default and is the only mode intended for real operations. `SETTLEMENT_MODE=simulation` creates a fake `SIMULATION-...` reference and marks a ticket complete without sending or verifying funds; use it only for testing.

There is no wallet integration, automatic payout signer, refund wallet, or private-key handling in this project.

## Data and recovery

Runtime state is stored in `middleman_data.json`. It includes ticket records, statistics, privacy settings, claimed deposit transaction IDs, and a bounded audit trail. Writes use a temporary file followed by an atomic rename. Back up this file securely if you need recovery, but treat it as sensitive because it contains addresses and transaction references.

The bot resumes active deposit monitors, completed-output delivery, and release/address countdowns after a restart. If the existing `middleman_data.json` came from the original Python bot, the first startup automatically migrates its snake_case keys to the JavaScript camelCase schema. It does not restore a countdown whose Discord message was deleted.

## Safety notes

- Keep the Discord token and API keys only in environment variables.
- Use separate deposit addresses or a carefully reviewed accounting strategy for production; this implementation uses configured shared deposit addresses and baseline transaction filtering.
- Test every state transition with test funds before production use.
- Cancellation after a deposit is marked `cancelledPendingSettlement` and requires an administrator to handle a refund or settlement process; this rewrite does not automatically issue refunds.
- Demo activity is disabled by default. If enabled, it posts a clearly labeled public blockchain sample as demonstration activity, not as a real Quantum-MM escrow trade.
