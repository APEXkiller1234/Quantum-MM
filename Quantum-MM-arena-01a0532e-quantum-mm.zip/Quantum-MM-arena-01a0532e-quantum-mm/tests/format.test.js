import test from 'node:test';
import assert from 'node:assert/strict';
import { cryptoAmount, money, parsePositiveDecimal, requiredCryptoDisplay } from '../src/utils/format.js';

test('money formats USD with cents and separators', () => {
  assert.equal(money('12345.678'), '$12,345.68');
});

test('positive decimal parser rejects invalid and non-positive values', () => {
  assert.equal(parsePositiveDecimal('$1,234.50').toFixed(2), '1234.50');
  assert.equal(parsePositiveDecimal('0'), null);
  assert.equal(parsePositiveDecimal('not money'), null);
});

test('crypto formatting respects asset precision', () => {
  assert.equal(cryptoAmount({ type: 'ltc' }, '1.123456789'), '1.12345678');
  assert.equal(cryptoAmount({ type: 'usdt' }, '1.239'), '1.23');
  assert.equal(requiredCryptoDisplay({ type: 'ltc', cryptoAmount: '1.123459' }), '1.12345');
});
