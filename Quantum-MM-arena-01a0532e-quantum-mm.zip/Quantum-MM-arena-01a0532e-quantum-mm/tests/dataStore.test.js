import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DataStore } from '../src/storage/dataStore.js';

test('migrates the original Python snake_case data format', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'quantum-mm-'));
  const path = join(directory, 'middleman_data.json');
  await writeFile(path, JSON.stringify({
    next_ticket_number: 7,
    stats: { '123': { deals_completed: 2, total_usd_value: '40.00' } },
    claimed_deposit_txids: { abc: 1 },
    tickets: { channel: { channel_id: 'channel', status: 'trade', messages: { role_selection: 'message' } } }
  }));
  const store = new DataStore(path, 1);
  await store.init();
  assert.equal(store.snapshot.schemaVersion, 2);
  assert.equal(store.snapshot.nextTicketNumber, 7);
  assert.equal(store.snapshot.stats['123'].dealsCompleted, 2);
  assert.equal(store.snapshot.claimedDepositTxids.abc, 1);
  assert.equal(store.snapshot.tickets.channel.messages.roleSelection, 'message');
  await rm(directory, { recursive: true, force: true });
});
