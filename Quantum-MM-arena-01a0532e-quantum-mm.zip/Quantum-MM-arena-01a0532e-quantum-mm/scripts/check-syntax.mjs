import { execFileSync } from 'node:child_process';
import { readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

function filesIn(directory) {
  const result = [];
  for (const entry of readdirSync(directory)) {
    const path = join(directory, entry);
    if (entry === 'node_modules' || entry === '.git') continue;
    if (statSync(path).isDirectory()) result.push(...filesIn(path));
    else if (path.endsWith('.js') || path.endsWith('.mjs')) result.push(path);
  }
  return result;
}

const files = filesIn(process.cwd()).filter((path) => !path.includes(`${join('tests', '')}`));
for (const file of files) execFileSync(process.execPath, ['--check', file], { stdio: 'inherit' });
console.log(`Syntax OK: ${files.length} JavaScript files checked.`);
